-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2019 at 10:15 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kokires22`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_detail_jual`
--

CREATE TABLE `tbl_detail_jual` (
  `d_jual_id` int(11) NOT NULL,
  `d_jual_nofak` varchar(15) DEFAULT NULL,
  `d_jual_barang_id` varchar(15) DEFAULT NULL,
  `d_jual_barang_nama` varchar(150) DEFAULT NULL,
  `d_jual_barang_satuan` varchar(30) DEFAULT NULL,
  `d_jual_barang_harjul` double DEFAULT NULL,
  `d_jual_qty` int(11) DEFAULT NULL,
  `d_jual_total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_detail_jual`
--

INSERT INTO `tbl_detail_jual` (`d_jual_id`, `d_jual_nofak`, `d_jual_barang_id`, `d_jual_barang_nama`, `d_jual_barang_satuan`, `d_jual_barang_harjul`, `d_jual_qty`, `d_jual_total`) VALUES
(1, '010619000001', 'BR000014', 'Ice Lemon Tea', 'Gelas', 20000, 2, 40000),
(2, '010619000001', 'BR000003', 'Ayam Goreng Lalapan', 'Porsi', 59000, 2, 118000),
(3, '010619000001', 'BR000002', 'Kentang Goreng', 'Porsi', 20000, 1, 20000),
(4, '020619000001', 'BR000001', 'Soto Ayam', 'Porsi', 45000, 10, 450000),
(5, '020619000001', 'BR000014', 'Ice Lemon Tea', 'Gelas', 20000, 10, 200000),
(6, '020619000001', 'BR000012', 'Risolles', 'Porsi', 29000, 5, 145000),
(7, '020619000002', 'BR000001', 'Soto Ayam', 'Porsi', 45000, 10, 450000),
(8, '020619000002', 'BR000014', 'Ice Lemon Tea', 'Gelas', 20000, 10, 200000),
(9, '020619000002', 'BR000012', 'Risolles', 'Porsi', 29000, 5, 145000),
(10, '020619000003', 'BR000004', 'Meun Kalbichim', 'Porsi', 195000, 6, 1170000),
(11, '020619000003', 'BR000007', 'Spagheti Seafood', 'Porsi', 85000, 4, 340000),
(12, '020619000003', 'BR000018', 'Water Melon Juice', 'Gelas', 25000, 2, 50000),
(13, '020619000003', 'BR000017', 'Pineapple Juice', 'Gelas', 25000, 4, 100000),
(14, '030619000001', 'BR000004', 'Meun Kalbichim', 'Porsi', 195000, 4, 780000),
(15, '030619000001', 'BR000005', 'English pork or beef Saussage', 'Porsi', 85000, 2, 170000),
(16, '030619000001', 'BR000010', 'Cumi Butter Garlic', 'Porsi', 65000, 4, 260000),
(17, '030619000001', 'BR000009', 'Kalbisal Kui', 'Porsi', 250000, 1, 250000),
(18, '030619000001', 'BR000019', 'Avocado Juice', 'Gelas', 30000, 2, 60000),
(19, '100619000001', 'BR000014', 'Ice Lemon Tea', 'Gelas', 20000, 6, 120000),
(20, '100619000001', 'BR000002', 'Kentang Goreng', 'Porsi', 20000, 1, 20000),
(21, '030819000001', 'BR000001', 'Soto Ayam', 'Porsi', 45000, 1, 45000),
(22, '030819000002', 'BR000002', 'Kentang Goreng', 'Porsi', 20000, 1, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jual`
--

CREATE TABLE `tbl_jual` (
  `jual_nofak` varchar(15) NOT NULL,
  `jual_tanggal` timestamp NULL DEFAULT current_timestamp(),
  `jual_tax` double NOT NULL,
  `jual_service` double NOT NULL,
  `jual_diskon` float NOT NULL,
  `jual_total` double DEFAULT NULL,
  `jual_jml_uang` double DEFAULT NULL,
  `jual_kembalian` double DEFAULT NULL,
  `jual_user_id` int(11) DEFAULT NULL,
  `jual_pax` int(11) NOT NULL,
  `jual_table` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_jual`
--

INSERT INTO `tbl_jual` (`jual_nofak`, `jual_tanggal`, `jual_tax`, `jual_service`, `jual_diskon`, `jual_total`, `jual_jml_uang`, `jual_kembalian`, `jual_user_id`, `jual_pax`, `jual_table`) VALUES
('010619000001', '2019-06-01 07:59:02', 17800, 8900, 10, 204700, 200000, -4700, 4, 2, 12),
('020619000001', '2019-06-02 08:48:44', 79500, 39750, 10, 914250, 850000, -64250, 3, 10, 2),
('020619000002', '2019-06-02 09:04:29', 79500, 39750, 10, 914250, 850000, -64250, 3, 10, 2),
('020619000003', '2019-06-02 09:25:05', 166000, 83000, 0, 1909000, 2000000, 91000, 3, 6, 3),
('030619000001', '2019-06-03 09:34:39', 152000, 76000, 0, 1748000, 1800000, 52000, 3, 8, 7),
('030819000001', '2019-08-03 07:58:51', 4500, 2250, 0, 51750, 52000, 250, 3, 2, 2),
('030819000002', '2019-08-03 08:00:01', 2000, 1000, 0, 23000, 23000, 0, 4, 4, 4),
('040519000001', '2019-05-04 15:40:21', 20000, 10000, 10, 230000, 250000, 20000, 4, 2, 5),
('040519000002', '2019-05-04 15:42:21', 13500, 6750, 0, 155250, 200000, 44750, 4, 2, 12),
('040519000003', '2019-05-04 15:45:30', 50000, 25000, 0, 575000, 600000, 25000, 4, 10, 15),
('040519000004', '2019-05-04 15:46:38', 34000, 17000, 25, 391000, 400000, 9000, 4, 10, 15),
('050519000001', '2019-05-05 15:48:40', 2500, 1250, 0, 28750, 30000, 1250, 4, 1, 2),
('100619000001', '2019-06-10 14:44:30', 14000, 7000, 10, 161000, 200000, 39000, 4, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE `tbl_kategori` (
  `kategori_id` int(11) NOT NULL,
  `kategori_nama` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`kategori_id`, `kategori_nama`) VALUES
(40, 'Camilan'),
(41, 'Minuman'),
(42, 'Makanan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_keuangan`
--

CREATE TABLE `tbl_keuangan` (
  `id_keuangan` int(11) NOT NULL,
  `tgl_input` date NOT NULL,
  `modal` double NOT NULL,
  `prive` double NOT NULL,
  `gaji` double NOT NULL,
  `hutang` double NOT NULL,
  `piutang` double NOT NULL,
  `pembelian` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_keuangan`
--

INSERT INTO `tbl_keuangan` (`id_keuangan`, `tgl_input`, `modal`, `prive`, `gaji`, `hutang`, `piutang`, `pembelian`) VALUES
(5, '2019-05-04', 10000000, 100000, 200000, 100000, 200000, 200000),
(7, '2019-06-01', 8000000, 0, 0, 0, 0, 0),
(8, '2019-08-03', 100000, 100000, 100000, 100000, 200000, 400000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `menu_id` varchar(15) NOT NULL,
  `menu_nama` varchar(150) DEFAULT NULL,
  `menu_satuan` varchar(30) DEFAULT NULL,
  `menu_harga` double DEFAULT NULL,
  `menu_stok` int(11) DEFAULT 0,
  `menu_foto` varchar(50) NOT NULL,
  `menu_min_stok` int(11) DEFAULT 0,
  `menu_tgl_input` timestamp NULL DEFAULT current_timestamp(),
  `menu_tgl_last_update` datetime DEFAULT NULL,
  `menu_kategori_id` int(11) DEFAULT NULL,
  `menu_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`menu_id`, `menu_nama`, `menu_satuan`, `menu_harga`, `menu_stok`, `menu_foto`, `menu_min_stok`, `menu_tgl_input`, `menu_tgl_last_update`, `menu_kategori_id`, `menu_user_id`) VALUES
('BR000001', 'Soto Ayam', 'Porsi', 45000, 34, 'foto1559364376.jpg', 10, '2019-06-01 04:46:16', '2019-06-27 11:47:40', 42, 4),
('BR000002', 'Kentang Goreng', 'Porsi', 20000, 24, 'foto1559368189.jpg', 5, '2019-06-01 04:53:02', '2019-08-03 15:06:42', 40, 4),
('BR000003', 'Ayam Goreng Lalapan', 'Porsi', 59000, 30, 'foto1559365420.jpg', 7, '2019-06-01 05:03:40', '2019-06-27 11:48:10', 42, 4),
('BR000004', 'Meun Kalbichim', 'Porsi', 195000, 22, 'foto1559366411.jpg', 10, '2019-06-01 05:04:51', '2019-06-01 13:21:18', 42, 4),
('BR000005', 'English pork or beef Saussage', 'Porsi', 85000, 11, 'foto1559368160.jpg', 5, '2019-06-01 05:06:39', '2019-06-01 13:49:20', 42, 4),
('BR000006', 'Goulash Soup', 'Porsi', 35000, 12, 'foto1559365961.jpg', 4, '2019-06-01 05:12:41', NULL, 42, 4),
('BR000007', 'Spagheti Seafood', 'Porsi', 85000, 16, 'foto1559366078.jpg', 12, '2019-06-01 05:14:38', NULL, 42, 4),
('BR000008', 'Chef Salad', 'Porsi', 65000, 16, 'foto1559366135.jpg', 5, '2019-06-01 05:15:35', NULL, 42, 4),
('BR000009', 'Kalbisal Kui', 'Porsi', 250000, 34, 'foto1559366232.jpg', 15, '2019-06-01 05:17:13', NULL, 42, 4),
('BR000010', 'Cumi Butter Garlic', 'Porsi', 65000, 20, 'foto1559366523.jpg', 7, '2019-06-01 05:22:03', '2019-06-27 11:48:58', 42, 4),
('BR000011', 'Jeyuk Bokeum', 'Porsi', 90000, 28, 'foto1559367711.jpg', 12, '2019-06-01 05:41:51', NULL, 42, 4),
('BR000012', 'Risolles', 'Porsi', 29000, 12, 'foto1559368258.jpg', 2, '2019-06-01 05:42:42', '2019-06-01 13:50:58', 42, 4),
('BR000013', 'Garlic Bread', 'Porsi', 15000, 15, 'foto1559368523.jpg', 3, '2019-06-01 05:55:23', NULL, 40, 4),
('BR000014', 'Ice Lemon Tea', 'Gelas', 20000, 30, 'foto1559370429.jpg', 10, '2019-06-01 06:27:09', '2019-06-27 11:46:35', 41, 4),
('BR000015', 'Cappucino', 'Gelas', 25000, 15, 'foto1559371723.jpg', 5, '2019-06-01 06:47:59', '2019-06-01 14:48:43', 41, 4),
('BR000016', 'Mango Juice', 'Gelas', 25000, 20, 'foto1559372121.jpg', 7, '2019-06-01 06:50:39', '2019-06-01 14:55:21', 41, 4),
('BR000017', 'Pineapple Juice', 'Gelas', 25000, 18, 'foto1559371926.jpg', 7, '2019-06-01 06:52:06', NULL, 41, 4),
('BR000018', 'Water Melon Juice', 'Gelas', 25000, 22, 'foto1559371995.jpg', 6, '2019-06-01 06:53:15', '2019-06-27 11:48:28', 41, 4),
('BR000019', 'Avocado Juice', 'Gelas', 30000, 23, 'foto1559372036.jpg', 10, '2019-06-01 06:53:56', NULL, 41, 4),
('BR000020', 'Kiwi Diva', 'Gelas', 30000, 16, 'foto1559372169.jpg', 4, '2019-06-01 06:56:09', NULL, 41, 4),
('BR000021', 'Milk Shake Vanilla', 'Gelas', 30000, 25, 'foto1559372240.jpg', 12, '2019-06-01 06:57:20', NULL, 41, 4),
('BR000022', 'Sprite', 'Botol', 20000, 30, 'foto1559372367.jpg', 15, '2019-06-01 06:59:27', NULL, 41, 4),
('BR000023', 'Beer Bintang (Large)', 'Botol', 50000, 50, 'foto1559372456.jpg', 20, '2019-06-01 07:00:56', NULL, 41, 4),
('BR000024', 'Soju', 'Botol', 50000, 40, 'foto1559372512.jpg', 10, '2019-06-01 07:01:52', NULL, 41, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `user_nama` varchar(35) DEFAULT NULL,
  `user_username` varchar(30) DEFAULT NULL,
  `user_password` varchar(35) DEFAULT NULL,
  `user_level` varchar(2) DEFAULT NULL,
  `user_status` varchar(2) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_nama`, `user_username`, `user_password`, `user_level`, `user_status`) VALUES
(3, 'Kasir', 'Kasir', 'c7911af3adbd12a035b289556d96470a', '2', '1'),
(4, 'Admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', '1'),
(5, 'Accounting', 'accounting', 'd4c143f004d88b7286e6f999dea9d0d7', '1', '1'),
(6, 'Manager', 'manager', '1d0258c2440a8d19e716292b231e3190', '1', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
  ADD PRIMARY KEY (`d_jual_id`),
  ADD KEY `d_jual_barang_id` (`d_jual_barang_id`);

--
-- Indexes for table `tbl_jual`
--
ALTER TABLE `tbl_jual`
  ADD PRIMARY KEY (`jual_nofak`),
  ADD KEY `jual_user_id` (`jual_user_id`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Indexes for table `tbl_keuangan`
--
ALTER TABLE `tbl_keuangan`
  ADD PRIMARY KEY (`id_keuangan`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `barang_user_id` (`menu_user_id`),
  ADD KEY `barang_kategori_id` (`menu_kategori_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
  MODIFY `d_jual_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tbl_keuangan`
--
ALTER TABLE `tbl_keuangan`
  MODIFY `id_keuangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
  ADD CONSTRAINT `tbl_detail_jual_ibfk_1` FOREIGN KEY (`d_jual_barang_id`) REFERENCES `tbl_menu` (`menu_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD CONSTRAINT `tbl_menu_ibfk_1` FOREIGN KEY (`menu_user_id`) REFERENCES `tbl_user` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_menu_ibfk_2` FOREIGN KEY (`menu_kategori_id`) REFERENCES `tbl_kategori` (`kategori_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
