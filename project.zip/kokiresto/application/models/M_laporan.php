<?php
class M_laporan extends CI_Model{
	function get_data_penjualan(){
		$hsl=$this->db->query("SELECT jual_nofak,jual_tax,jual_service,menu_foto,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,jual_total,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,d_jual_total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak LEFT JOIN tbl_menu ON d_jual_barang_id=menu_id ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_total_penjualan(){
		$hsl=$this->db->query("SELECT jual_nofak,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,jual_total,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,SUM(d_jual_total) as total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_data_jual_pertanggal($tanggal){
		$hsl=$this->db->query("SELECT jual_nofak,jual_tax,jual_service,menu_foto,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,d_jual_total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak LEFT JOIN tbl_menu ON d_jual_barang_id=menu_id WHERE DATE(jual_tanggal)='$tanggal' ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_data__total_jual_pertanggal($tanggal){
		$hsl=$this->db->query("SELECT jual_nofak,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,SUM(d_jual_total) as total, jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak WHERE DATE(jual_tanggal)='$tanggal' ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_bulan_jual(){
		$hsl=$this->db->query("SELECT DISTINCT DATE_FORMAT(jual_tanggal,'%M %Y') AS bulan FROM tbl_jual ORDER BY jual_tanggal ASC");
		return $hsl;
	}
	function get_tahun_jual(){
		$hsl=$this->db->query("SELECT DISTINCT YEAR(jual_tanggal) AS tahun FROM tbl_jual");
		return $hsl;
	}
	function get_jual_bulan_tahun($tahun){
		$hsl=$this->db->query("SELECT DISTINCT DATE_FORMAT(jual_tanggal,'%M %Y') AS bulan FROM tbl_jual WHERE DATE_FORMAT(jual_tanggal,'%Y') = '$tahun' ORDER BY jual_tanggal ASC");
		return $hsl;
	}
	function get_jual_perbulan($bulan){
		$hsl=$this->db->query("SELECT jual_nofak,jual_tax,jual_service,menu_foto,DATE_FORMAT(jual_tanggal,'%M %Y') AS bulan,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,d_jual_total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak LEFT JOIN tbl_menu ON d_jual_barang_id=menu_id WHERE DATE_FORMAT(jual_tanggal,'%M %Y')='$bulan' ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_total_jual_perbulan($bulan){
		$hsl=$this->db->query("SELECT jual_nofak,DATE_FORMAT(jual_tanggal,'%M %Y') AS bulan,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,SUM(d_jual_total) as total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak WHERE DATE_FORMAT(jual_tanggal,'%M %Y')='$bulan' ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_jual_pertahun($tahun){
		$hsl=$this->db->query("SELECT jual_nofak,jual_tax,jual_service,menu_foto,YEAR(jual_tanggal) AS tahun,DATE_FORMAT(jual_tanggal,'%M %Y') AS bulan,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,d_jual_total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak LEFT JOIN tbl_menu ON d_jual_barang_id=menu_id WHERE YEAR(jual_tanggal)='$tahun' ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_total_jual_pertahun($tahun){
		$hsl=$this->db->query("SELECT jual_nofak,YEAR(jual_tanggal) AS tahun,DATE_FORMAT(jual_tanggal,'%M %Y') AS bulan,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,SUM(d_jual_total) as total FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak WHERE YEAR(jual_tanggal)='$tahun' ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_data_jual_periode($tgl1, $tgl2){
		$hsl=$this->db->query("SELECT jual_nofak,jual_tax,jual_service,menu_foto,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,d_jual_total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak LEFT JOIN tbl_menu ON d_jual_barang_id=menu_id WHERE  DATE(jual_tanggal) >= '$tgl1' AND DATE(jual_tanggal) <='$tgl2' ORDER BY DATE(jual_tanggal) ASC");
		return $hsl;
	}
	function get_total_jual_periode($tgl1, $tgl2){
		$hsl=$this->db->query("SELECT jual_nofak,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,SUM(d_jual_total) as total, jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak WHERE DATE(jual_tanggal) >='$tgl1' AND  DATE(jual_tanggal) <='$tgl2' ORDER BY DATE(jual_tanggal) ASC");
		return $hsl;
	}
	function get_data_menu_terlaris($tgl, $tgl2){
		$hsl=$this->db->query("SELECT SUM(d_jual_qty) AS qty,menu_id,menu_nama,menu_foto,menu_harga FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak JOIN tbl_menu ON d_jual_barang_id=menu_id WHERE DATE(jual_tanggal) BETWEEN '$tgl' AND '$tgl2' GROUP BY menu_id ORDER BY qty DESC");
		return $hsl;
	}
	function get_pendapatan_bulan($bulan){
		$hsl=$this->db->query("SELECT jual_nofak, jual_tax, jual_service, jual_diskon, jual_total FROM tbl_jual WHERE DATE_FORMAT(jual_tanggal,'%M %Y')='$bulan'");
		return $hsl;
	}
	function get_detail_jual(){
		$hsl=$this->db->query("SELECT * FROM tbl_menu");
		return $hsl;
	}
	function get_jual_bulan($bulan){
		$hsl=$this->db->query("SELECT jual_nofak, jual_tax, jual_service, jual_diskon, jual_total FROM tbl_jual WHERE DATE_FORMAT(jual_tanggal,'%M %Y')='$bulan'");
		return $hsl;
	}
	function get_pendapatan($id_fak){
		$hsl=$this->db->query("SELECT SUM(d_jual_total) AS harga FROM tbl_detail_jual JOIN tbl_menu ON d_jual_barang_id = menu_id WHERE d_jual_nofak='$id_fak' GROUP BY d_jual_nofak");
		return $hsl;
	}
	function get_lap_pendapatan($bulan){
		$hsl=$this->db->query("SELECT jual_tax,jual_service,d_jual_barang_harjul,d_jual_qty,d_jual_total,jual_diskon FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak WHERE DATE_FORMAT(jual_tanggal,'%M %Y')='$bulan'");
		return $hsl;
	}
	function get_keuangan($bulan){
		$hsl=$this->db->query("SELECT * FROM tbl_keuangan WHERE DATE_FORMAT(tgl_input, '%M %Y')='$bulan'");
		return $hsl;
	}
	function get_bln_modal(){
		$hsl=$this->db->query("SELECT DATE_FORMAT(tgl_input,'%M %Y') AS bln FROM tbl_keuangan ORDER BY tgl_input DESC");
		return $hsl;
	}
	function get_pendapatan_sebelum($bulan){
		$hsl=$this->db->query("SELECT SUM(jual_total) AS harga, DATE_FORMAT(jual_tanggal,'%M %Y') AS tgl FROM tbl_jual GROUP BY DATE_FORMAT(jual_tanggal,'%M %Y')");
		return $hsl;
	}
	function get_pengeluaran_sebelum($bulan){
		$hsl=$this->db->query("SELECT SUM(d_beli_total) AS total, DATE_FORMAT(beli_tanggal,'%M %Y') AS tgl FROM tbl_beli b JOIN tbl_detail_beli db ON (b.beli_kode = db.d_beli_kode) GROUP BY DATE_FORMAT(beli_tanggal,'%M %Y')");
		return $hsl; 
	}
	function get_retur_sebelum($bulan){
		$hsl=$this->db->query("SELECT SUM((retur_harjul * retur_qty)) AS harga, DATE_FORMAT(retur_tanggal,'%M %Y') AS tgl FROM tbl_retur GROUP BY DATE_FORMAT(retur_tanggal,'%M %Y')");
		return $hsl;
	}
	function get_keuangan_sebelum($bulan){
		$hsl=$this->db->query("SELECT DATE_FORMAT(tgl_input,'%M %Y') AS tgl, modal, prive, gaji, hutang, piutang, pembelian FROM tbl_keuangan");
		return $hsl;
	}
	
	function get_keuangan_sum($bulan){
		$hsl=$this->db->query("SELECT sum(modal) as modal, sum(gaji) as gaji, sum(hutang) as hutang FROM tbl_keuangan WHERE DATE_FORMAT(tgl_input, '%M %Y')='$bulan'");
		return $hsl;
	}

	function get_pengeluaran($bulan) {
		$hsl=$this->db->query("SELECT sum(gaji) as gaji, sum(pembelian) as pembelian FROM tbl_keuangan WHERE DATE_FORMAT(tgl_input, '%M %Y')='$bulan'");
		return $hsl;
	}
}
