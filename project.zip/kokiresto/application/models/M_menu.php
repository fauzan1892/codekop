<?php
class M_menu extends CI_Model{ 

	function hapus_menu($kode){
		$hsl=$this->db->query("DELETE FROM tbl_menu where menu_id='$kode'");
		return $hsl;
	}

	function update_menu($kobar,$nabar,$kat,$satuan,$harga,$stok,$min_stok, $gbr){
		$user_id=$this->session->userdata('idadmin');
		$hsl=$this->db->query("UPDATE tbl_menu SET menu_nama='$nabar',menu_satuan='$satuan',menu_harga='$harga',menu_stok='$stok',menu_min_stok='$min_stok',menu_tgl_last_update=NOW(),menu_foto='$gbr',menu_kategori_id='$kat',menu_user_id='$user_id' WHERE menu_id='$kobar'");
		return $hsl;
	}

	function tampil_menu(){
		$hsl=$this->db->query("SELECT menu_id,menu_nama,menu_satuan,menu_harga,menu_stok,menu_min_stok,menu_kategori_id,kategori_nama,menu_foto FROM tbl_menu JOIN tbl_kategori ON menu_kategori_id=kategori_id");
		return $hsl;
	}

	function simpan_menu($kobar,$nabar,$kat,$satuan,$harga,$stok,$min_stok, $gbr){
		$user_id=$this->session->userdata('idadmin');
		$hsl=$this->db->query("INSERT INTO tbl_menu (menu_id,menu_nama,menu_satuan,menu_harga,menu_stok,menu_min_stok,menu_kategori_id,menu_user_id,menu_foto) VALUES ('$kobar','$nabar','$satuan','$harga','$stok','$min_stok','$kat','$user_id','$gbr')");
		return $hsl;
	}


	function get_menu($kobar){
		$hsl=$this->db->query("SELECT * FROM tbl_menu where menu_id='$kobar'");
		return $hsl;
	}

	function get_kobar(){
		$q = $this->db->query("SELECT MAX(RIGHT(menu_id,6)) AS kd_max FROM tbl_menu");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%06s", $tmp);
            }
        }else{
            $kd = "000001";
        }
        return "BR".$kd; 
	}

}