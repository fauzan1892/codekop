<?php
class M_keuangan extends CI_Model{ 

	function insert($data){
		$hsl=$this->db->insert('tbl_keuangan', $data);
		return $hsl;
	}

	function cek_input($tgl){
		$hsl=$this->db->query("SELECT * FROM tbl_keuangan WHERE DATE_FORMAT(tgl_input,'%M %Y') = '$tgl'")
						->num_rows();
		return $hsl;
	}

	function tampil_keuangan(){
		$hsl=$this->db->query("SELECT * FROM tbl_keuangan ORDER BY tgl_input DESC");
		return $hsl;
	}

	function update($data, $id){
		$hsl=$this->db->update('tbl_keuangan',$data,$id);
		return $hsl;
	}

	function hapus($id){
		$hsl=$this->db->delete('tbl_keuangan',$id);
	}
}