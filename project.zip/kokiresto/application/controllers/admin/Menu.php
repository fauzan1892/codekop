<?php
class Menu extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url();
            redirect($url);
        }; 
		$this->load->model('m_kategori');
		$this->load->model('m_menu');
		$this->load->library('barcode');
	}

	function index(){
		if($this->session->userdata('akses')=='1'){
			$data['data']=$this->m_menu->tampil_menu();
			$data['kat']=$this->m_kategori->tampil_kategori();
			$data['kat2']=$this->m_kategori->tampil_kategori();
			$this->load->view('admin/v_menu',$data);
		}else{
	        echo "Halaman tidak ditemukan";
	    }
	}

	function tambah_menu(){
	if($this->session->userdata('akses')=='1'){

		$config['upload_path'] = './assets/foto/';
		$config['allowed_types'] = 'jpg|png|jpeg';
		$config['max_size'] = '2048';
		$config['file_name'] = 'foto'.time();

		$this->load->library('upload', $config);

		if ($this->upload->do_upload('foto'))
		{
			$kobar=$this->m_menu->get_kobar();
			$nabar=$this->input->post('nabar');
			$kat=$this->input->post('kategori');
			$satuan=$this->input->post('satuan');
			$harga=str_replace(',', '', $this->input->post('harga'));
			$stok=$this->input->post('stok');
			$min_stok=$this->input->post('min_stok');
			$gbr = $this->upload->data();

			$this->m_menu->simpan_menu($kobar,$nabar,$kat,$satuan,$harga,$stok,$min_stok,$gbr['file_name']);

			redirect('admin/menu');
		}
		else
		{
			echo $this->upload->display_errors();
		}
	}else{
        echo "Halaman tidak ditemukan";
    }
	}
	function edit_menu(){
	if($this->session->userdata('akses')=='1'){
		$config['upload_path'] = './assets/foto/';
		$config['allowed_types'] = 'jpg|png|jpeg';
		$config['max_size'] = '2048';
		$config['file_name'] = 'foto'.time();

		$this->load->library('upload', $config);

		if ($this->upload->do_upload('foto'))
		{
			$gbr=$this->upload->data();
			$foto=$gbr['file_name'];
			//hapus foto lama
			unlink('./assets/foto/'.$this->input->post('old_pict'));
		}else{
			$foto=$this->input->post('old_pict');
		}

		$kobar=$this->input->post('kobar');
		$nabar=$this->input->post('nabar');
		$kat=$this->input->post('kategori');
		$satuan=$this->input->post('satuan');
		$harga=str_replace(',', '', $this->input->post('harga'));
		$stok=$this->input->post('stok');
		$min_stok=$this->input->post('min_stok');
		$this->m_menu->update_menu($kobar,$nabar,$kat,$satuan,$harga,$stok,$min_stok,$foto);
		redirect('admin/menu');
	}else{
        echo "Halaman tidak ditemukan";
    }
	}
	function hapus_menu(){
	if($this->session->userdata('akses')=='1'){
		$kode=$this->input->post('kode');
		$this->m_menu->hapus_menu($kode);
		redirect('admin/menu');
	}else{
        echo "Halaman tidak ditemukan";
    }
	} 
}