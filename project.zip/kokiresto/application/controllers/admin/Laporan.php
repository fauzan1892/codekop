<?php
class Laporan extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url();
            redirect($url); 
        };
		$this->load->model('m_kategori');
		$this->load->model('m_menu');
		$this->load->model('m_penjualan');
		$this->load->model('m_laporan');
	}
	function index(){
	if($this->session->userdata('akses')=='1'){
		$data['data']=$this->m_menu->tampil_menu();
		$data['kat']=$this->m_kategori->tampil_kategori();
		$data['jual_bln']=$this->m_laporan->get_bulan_jual();
		$data['jual_thn']=$this->m_laporan->get_tahun_jual();
		$data['bln_modal']=$this->m_laporan->get_bln_modal();
		$this->load->view('admin/v_laporan',$data);
	}else{
        echo "Halaman tidak ditemukan";
    }
	}
	function lap_data_penjualan(){
		$x['data']=$this->m_laporan->get_data_penjualan();
		$x['jml']=$this->m_laporan->get_total_penjualan();
		$this->load->view('admin/laporan/v_lap_penjualan',$x);
	}
	function lap_penjualan_pertanggal(){
		$tanggal=$this->input->post('tgl');
		$x['jml']=$this->m_laporan->get_data__total_jual_pertanggal($tanggal);
		$x['data']=$this->m_laporan->get_data_jual_pertanggal($tanggal);
		$this->load->view('admin/laporan/v_lap_jual_pertanggal',$x);
	}
	function lap_penjualan_perbulan(){
		$bulan=$this->input->post('bln');
		$x['jml']=$this->m_laporan->get_total_jual_perbulan($bulan);
		$x['data']=$this->m_laporan->get_jual_perbulan($bulan);
		$this->load->view('admin/laporan/v_lap_jual_perbulan',$x);
	}
	function lap_penjualan_pertahun(){
		$tahun=$this->input->post('thn');
		$x['jml']=$this->m_laporan->get_total_jual_pertahun($tahun);
		$x['data']=$this->m_laporan->get_jual_pertahun($tahun);
		$x['bln']=$this->m_laporan->get_jual_bulan_tahun($tahun);
		$this->load->view('admin/laporan/v_lap_jual_pertahun',$x);
	}
	function lap_periode(){
		$tgl1=$this->input->post('tgl1');
		$tgl2=$this->input->post('tgl2');
		$x['jml']=$this->m_laporan->get_total_jual_periode($tgl1, $tgl2);
		$x['data']=$this->m_laporan->get_data_jual_periode($tgl1, $tgl2);
		$x['periode']=date('d F Y', strtotime($tgl1)).' s/d '.date('d F Y', strtotime($tgl2));
		$this->load->view('admin/laporan/v_lap_periode', $x);
	}
	function lap_menu_terlaris(){
		$tgl=$this->input->post('tgl');
		$tgl2=$this->input->post('tgl2');
		$x['data']=$this->m_laporan->get_data_menu_terlaris($tgl,$tgl2);
		$x['tgl1']=date('d F Y', strtotime($tgl));
		$x['tgl2']=date('d F Y', strtotime($tgl2));
		$this->load->view('admin/laporan/v_lap_menu', $x);
	}
	function lap_buku_besar(){
		$bulan=$this->input->post('bln');
		$x['keuangan']=$this->m_laporan->get_keuangan($bulan);
		$get_pendapatan = $this->m_laporan->get_lap_pendapatan($bulan);
		$pendapatan = 0;
		foreach ($get_pendapatan->result() as $i) {
			$harjul=$i->d_jual_barang_harjul;
	        $qty=$i->d_jual_qty;
	        $tax=($harjul*10/100);
	        $service=($harjul*5/100);
	        $diskon=($harjul*$i->jual_diskon)/100;
	        $total=$i->d_jual_total+($tax*$qty)+($service*$qty)-($diskon*$qty);
	        $pendapatan += $total;
		}
		$x['pendapatan']= $pendapatan;
		$x['bulan'] = $bulan;
		$this->load->view('admin/laporan/v_lap_buku_besar',$x); 
	}
	function lap_modal(){
		$bulan=$this->input->post('bln');
		$x['keuangan']=$this->m_laporan->get_keuangan($bulan);
		$get_pendapatan = $this->m_laporan->get_lap_pendapatan($bulan);
		$pendapatan = 0;
		foreach ($get_pendapatan->result() as $i) {
			$harjul=$i->d_jual_barang_harjul;
	        $qty=$i->d_jual_qty;
	        $tax=($harjul*10/100);
	        $service=($harjul*5/100);
	        $diskon=($harjul*$i->jual_diskon)/100;
	        $total=$i->d_jual_total+($tax*$qty)+($service*$qty)-($diskon*$qty);
	        $pendapatan += $total;
		}
		$x['pendapatan']= $pendapatan;
		$x['bulan'] = $bulan;
		$this->load->view('admin/laporan/v_lap_modal',$x); 
	}
	function lap_neraca_saldo(){
		$bulan=$this->input->post('bln');
		$x['keuangan']=$this->m_laporan->get_keuangan($bulan);
		$x['pendapatan']=$this->m_laporan->get_pendapatan($bulan);
		$x['bulan'] = $bulan;
		$this->load->view('admin/laporan/v_lap_neraca_saldo',$x); 
	}
	
	function lap_neraca(){
		$bulan=$this->input->post('bln');
		$x['report']=$this->m_laporan->get_keuangan_sum($bulan)->row();
		
		$x['keuangan']=$this->m_laporan->get_keuangan($bulan);
		$x['pendapatan']=$this->m_laporan->get_pendapatan($bulan);
		$x['bulan'] = $bulan;
		$this->load->view('admin/laporan/v_lap_neraca',$x); 
	}
	
	function lap_laba_rugi(){
		$bulan=$this->input->post('bln');
		$data_penjualan = $this->m_laporan->get_pendapatan_bulan($bulan);
		$pendapatan = 0;
		foreach ($data_penjualan->result() as $p) {
			$pe = $this->m_laporan->get_pendapatan($p->jual_nofak);
			$harga = ($pe->num_rows() > 0) ? $pe->row()->harga : 0;
			$tax=($harga*10/100);
	        $service=($harga*5/100);
	        $diskon=($harga*$p->jual_diskon)/100;

			$pendapatan += $harga + $tax + $service - $diskon;
		}

		$detail_jual = $this->m_laporan->get_detail_jual(); // cari di model/ M_laporan 
		$data_penjualan = $this->m_laporan->get_jual_bulan($bulan); 
		$persediaanawal = 0;
		$persediaanakhir = 0;
		$hargaawal = 0;
		$harga_jual = 0;
		$hpp = 0;
		$harga_akhir = 0;
		$peralatan = 0;

		foreach ($detail_jual->result() as $p) {
			$hargaawal += $p->menu_harga * $p->menu_stok;
			$sql = $this->db->query("SELECT * FROM tbl_detail_jual WHERE d_jual_barang_id ='$p->menu_id'");
			foreach ($sql->result() as $q) {
				$harga_jual += $q->d_jual_total;
			}
		}

		foreach ($data_penjualan->result() as $p) {
			$harga_akhir += $p->jual_total;
		}

		$keuangan=$this->db->query("SELECT * FROM tbl_keuangan WHERE DATE_FORMAT(tgl_input,'%M %Y')='$bulan'");
		foreach ($keuangan->result() as $a){
			$peralatan += $a->pembelian;
		}

		$persediaanawal = $hargaawal + $harga_jual;
		$persediaanakhir = $persediaanawal - $harga_akhir;
		$hpp = $persediaanawal + $peralatan - $persediaanakhir;

		$x['pendapatan']=$pendapatan;
		$x['hpp']=$hpp;
		$x['persediaanawal']=$persediaanawal;
		$x['persediaanakhir']=$persediaanakhir;
		$x['pengeluaran']=$this->m_laporan->get_pengeluaran($bulan);
		$x['bulan'] = $bulan;
		$this->load->view('admin/laporan/v_lap_laba_rugi',$x); 
	}
}
