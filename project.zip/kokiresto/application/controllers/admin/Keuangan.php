<?php
class Keuangan extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url();
            redirect($url); 
        };
        $this->load->model('m_keuangan');
	}
	function index(){
		if($this->session->userdata('akses')=='1'){
			$x['data']=$this->m_keuangan->tampil_keuangan();
			$this->load->view('admin/v_keuangan', $x);
		}else{
	        echo "Halaman tidak ditemukan";
	    }
	}
	function tambah(){
		if($this->session->userdata('akses')=='1'){
			if ($this->input->post('tgl', TRUE))
			{
				//cek apakah keuangan bulan ini sudah diinput atau belum
				if ($this->m_keuangan->cek_input(date("F Y", strtotime($this->input->post('tgl', TRUE)))) > 0)
				{
					echo '<script type="text/javascript">alert("Data bulan ini sudah ada, silahkan edit data jika ingin merubahnya");window.location.replace("'.base_url('admin/keuangan').'");</script>';
				}else{

					$data = array(
						'tgl_input' => $this->input->post('tgl', TRUE),
						'modal' => str_replace(',', '', $this->input->post('modal', TRUE)),
						'prive' => str_replace(',', '', $this->input->post('prive', TRUE)),
						'gaji'	=> str_replace(',', '', $this->input->post('gaji', TRUE)),
						'hutang' => str_replace(',', '', $this->input->post('hutang', TRUE)),
						'piutang' => str_replace(',', '', $this->input->post('piutang', TRUE)),
						'pembelian' => str_replace(',', '', $this->input->post('pembelian', TRUE))
					);

					$this->m_keuangan->insert($data);

					redirect('admin/keuangan');
				}
			}
			else
			{
				echo "Halaman tidak ditemukan";
			}
		}else{
	        echo "Halaman tidak ditemukan";
	    }
	}
	function edit(){
		if($this->session->userdata('akses')=='1'){
			if ($this->input->post('tgl', TRUE))
			{
				$data = array(
					'tgl_input' => $this->input->post('tgl', TRUE),
					'modal' => str_replace(',', '', $this->input->post('modal', TRUE)),
					'prive' => str_replace(',', '', $this->input->post('prive', TRUE)),
					'gaji'	=> str_replace(',', '', $this->input->post('gaji', TRUE)),
					'hutang' => str_replace(',', '', $this->input->post('hutang', TRUE)),
					'piutang' => str_replace(',', '', $this->input->post('piutang', TRUE)),
					'pembelian' => str_replace(',', '', $this->input->post('pembelian', TRUE))
				);

				$this->m_keuangan->update($data, array('id_keuangan' => $this->input->post('id')));

				redirect('admin/keuangan');
			}
			else
			{
				echo "Halaman tidak ditemukan";
			}
		}else{
	        echo "Halaman tidak ditemukan";
	    }
	}
	function hapus(){
		if($this->session->userdata('akses')=='1'){
			$kode=$this->input->post('kode');
			$this->m_keuangan->hapus(array('id_keuangan' => $kode));
			redirect('admin/keuangan');
		}else{
	        echo "Halaman tidak ditemukan";
	    }
	}
}