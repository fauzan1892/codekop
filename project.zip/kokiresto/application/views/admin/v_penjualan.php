<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Koki">
    <meta name="author" content="Koki">

    <title>Penjualan</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url().'assets/css/bootstrap.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/style.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/font-awesome/css/font-awesome.css'?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url().'assets/css/dataTables.bootstrap.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/jquery.dataTables.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/dist/css/bootstrap-select.css'?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap-datetimepicker.min.css'?>">

    <style type="text/css">
      #container {
        padding-left: 0;
        -webkit-transition: all 0.5s ease;
        -moz-transition: all 0.5s ease;
        -o-transition: all 0.5s ease;
        transition: all 0.5s ease;
      }

    #container.toggled {
        padding-left: 250px;
    }

    #sidebar {
        z-index: 1000;
        position: fixed;
        left: 250px;
        width: 0;
        height: 100%;
        margin-left: -250px;
        overflow-y: auto;
        background: #2c3e50;
        -webkit-transition: all 0.5s ease;
        -moz-transition: all 0.5s ease;
        -o-transition: all 0.5s ease;
        transition: all 0.5s ease;
    }

    #container.toggled #sidebar {
        width: 250px;
    }

    #page-content-container {
        width: 100%;
        position: absolute;
        padding: 15px;
    }

    #container.toggled #page-content-container {
        position: absolute;
        margin-right: -250px;
    }

    .sidebar-nav {
        position: absolute;
        top: 0;
        width: 250px;
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .sidebar-nav li {
        text-indent: 10px;
        line-height: 40px;
    }

    .sidebar-nav li h4{
      color: #fff;
      text-align: center;
      font-size: 25px;
        text-indent: 0px;
        line-height: 40px;
    }

    .sidebar-nav li a {
        display: block;
        text-decoration: none;
        color: #fff;
    }
    .sidebar-nav li a i.fa {
      margin-right: 5px;
    }
    .sidebar-nav li a:hover {
        text-decoration: none;
        color: #fff;
        background: #34495f;
    }

    .sidebar-nav li a:active,
    .sidebar-nav li a:focus {
        text-decoration: none;
    }

    .sidebar-nav li a.active {
      text-decoration: none;
        color: #fff;
      background: #34495f;
      border-right: 5px solid #0277bd;
    }

    .sidebar-nav > .sidebar-brand {
        height: 65px;
        font-size: 18px;
        line-height: 60px;
    }

    .sidebar-nav > .sidebar-brand a:hover {
        color: #fff;
        background: none;
        font-weight: bold;
    }
    .user-info {
      padding-left: 15px;
      color: #fff;
      margin-top: 20px;
    }
    .user-info img {
      float: left;
    }
    .user-info p {
      margin-top: -15px;
      font-weight: bold;
    }
    .avatar {
      border-radius: 50px;
      background: #fff;
      height: 60px;
      width: 60px;
    }
    #menunya {
      display: block;
      width: 100%;
    }
    .devider {
    }
    @media(min-width:768px) {
        #menunya {
          display: none;
        }
        #container {
            padding-left: 250px;
        }

        #container.toggled {
            padding-left: 0;
        }

        #sidebar {
            width: 250px;
        }

        #container.toggled #sidebar {
            width: 0;
        }

        #page-content-container {
            padding: 20px;
            position: relative;
        }

        #container.toggled #page-content-container {
            position: relative;
            margin-right: 0;
        }
    }
    @media(min-width:568px) {
      #menunya {
        display: none;
      }
    }
  </style>
</head>

<body>

    <div id="container">
        <?php echo $this->load->view('admin/menu_home'); ?>
        <div id="page-content-container">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <center><?php echo $this->session->flashdata('msg');?></center>
                        <h1 class="page-header">Transaksi
                            <small>Penjualan Menu Makanan</small>
                            <a href="#" data-toggle="modal" data-target="#largeModal" class="pull-right"><small>Cari Menu!</small></a>
                        </h1> 
                    </div>
                </div>
                <!-- /.row -->
                <!-- Projects Row -->
                <div class="row">
                    <div class="col-lg-12">
                        <form action="<?php echo base_url().'admin/penjualan/add_to_cart'?>" method="post">
                            <table>
                                <tr>
                                    <th>Kode Menu</th>
                                </tr>
                                <tr>
                                    <th><input type="text" name="kode_brg" id="kode_brg" class="form-control input-sm"></th>                     
                                </tr>
                                    <div id="detail_barang" style="position:absolute;">
                                    </div>
                            </table>
                        </form>
                        <form action="<?php echo base_url().'admin/penjualan/simpan_penjualan'?>" method="post">
                        <table style="margin-top:10px;">
                            <tr>
                                <th>Pax</th>
                                <th style="padding-left:10px;">Table</th>
                            </tr>
                            <tr>
                                <td><input type="number" name="pax" id="pax" class="form-control input-sm" required></td>
                                <td style="padding-left:10px;"><input type="number" name="table" id="table" class="form-control input-sm" required></td>                     
                            </tr>
                        </table>
                        <table class="table table-bordered table-condensed" style="font-size:11px;margin-top:10px;">
                            <thead>
                                <tr>
                                    <th>Kode Menu</th>
                                    <th>Nama Menu</th>
                                    <th style="text-align:center;">Foto</th>
                                    <th style="text-align:center;">Harga(Rp)</th>
                                    <th style="text-align:center;">Qty</th>
                                    <th style="text-align:center;">Sub Total</th>
                                    <th style="width:100px;text-align:center;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($this->cart->contents() as $items): ?>
                                <?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
                                <tr>
                                     <td style="vertical-align:middle"><?=$items['id'];?></td>
                                     <td style="vertical-align:middle"><?=$items['name'];?></td>
                                     <td style="text-align:center;width:120px;vertical-align:middle"><img src="<?= base_url('assets/foto/'.$items['foto']);?>" style="max-width:100px; max-height: 80px"></td>
                                     <td style="text-align:right;vertical-align:middle"><?php echo number_format($items['amount']);?></td>
                                     <td style="text-align:center;vertical-align:middle"><?php echo number_format($items['qty']);?></td>
                                     <td style="text-align:right;vertical-align:middle"><?php echo number_format($items['subtotal']);?></td>
                                    
                                     <td style="text-align:center;vertical-align:middle"><a href="<?php echo base_url().'admin/penjualan/remove/'.$items['rowid'];?>" class="btn btn-warning btn-xs"><span class="fa fa-close"></span> Batal</a></td>
                                </tr>
                                
                                <?php $i++; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                            <table>
                                <?php
                                $tax = $this->cart->total() * 10 / 100;
                                $service = $this->cart->total() * 5 / 100;
                                $total = $this->cart->total() + $tax + $service;
                                ?>
                                <tr>
                                    <td style="width:760px;" rowspan="7"><button type="submit" class="btn btn-info btn-lg"> Simpan</button></td>
                                    <th style="width:140px;">Tax (10%)</th>
                                    <th style="text-align:right;width:140px;"><input type="text" name="tax1" value="<?php echo number_format($tax);?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly></th>
                                    <input type="hidden" id="tax" name="tax" value="<?php echo $tax; ?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                                </tr>
								<tr>
                                    <th style="width:140px;">Service (5%)</th>
                                    <th style="text-align:right;width:140px;"><input type="text" name="service2" value="<?php echo number_format($service);?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly></th>
                                    <input type="hidden" id="service" name="service" value="<?php echo $service;?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                                </tr>
                                <tr>
                                    <th style="width:140px;">Discount (%)</th>
                                    <th style="text-align:right;width:140px;"><input type="text" name="discount" class="form-control input-sm discount" style="text-align:right;margin-bottom:5px;" id="discount"></th>
                                </tr>
                                <tr>
                                    <th style="width:140px;"></th>
                                    <th style="text-align:right;width:140px;"><input type="text" name="discount2" value="0" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" id="discount2" readonly></th>
                                </tr>
                                <tr>
                                    <th style="width:140px;">Total Belanja(Rp)</th>
                                    <th style="text-align:right;width:140px;"><input type="text" name="total2" value="<?php echo number_format($total);?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" id="total2" readonly></th>
                                    <input type="hidden" id="total" name="total" value="<?php echo $total; ?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                                </tr>
                                <tr>
                                    <th>Tunai(Rp)</th>
                                    <th style="text-align:right;"><input type="text" id="jml_uang" name="jml_uang" class="jml_uang form-control input-sm" style="text-align:right;margin-bottom:5px;" required></th>
                                    <input type="hidden" id="jml_uang2" name="jml_uang2" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" required>
                                </tr>
                                <tr>
                                    <th>Kembalian(Rp)</th>
                                    <th style="text-align:right;"><input type="text" id="kembalian" name="kembalian" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" required></th>
                                </tr>

                            </table>
                        </form>
                        <hr/>
                    </div>
                </div>
                <!-- /.row -->
                <!-- ============ MODAL ADD =============== -->
                <div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <h3 class="modal-title" id="myModalLabel">Data Menu</h3>
                            </div>
                            <div class="modal-body" style="overflow:scroll;height:500px;">

                                <table class="table table-bordered table-condensed" style="font-size:11px;" id="mydata">
                                    <thead>
                                        <tr>
                                            <th style="text-align:center;width:40px;">No</th>
                                            <th style="width:120px;">Kode Menu</th>
                                            <th style="width:240px;">Nama Menu</th>
                                            <th>Foto Menu</th>
                                            <th style="width:100px;">Harga</th>
                                            <th>Stok</th>
                                            <th style="width:100px;text-align:center;">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            $no=0;
                                            foreach ($data->result_array() as $a):
                                                $no++;
                                                $id=$a['menu_id'];
                                                $nm=$a['menu_nama'];
                                                $satuan=$a['menu_satuan'];
                                                $harga=$a['menu_harga'];
                                                $stok=$a['menu_stok'];
                                                $min_stok=$a['menu_min_stok'];
                                                $kat_id=$a['menu_kategori_id'];
                                                $kat_nama=$a['kategori_nama'];
                                                $foto=$a['menu_foto'];
                                        ?>
                                            <tr>
                                                <td style="text-align:center;vertical-align:middle;"><?php echo $no;?></td>
                                                <td style="text-align:center;vertical-align:middle;"><?php echo $id;?></td>
                                                <td style="text-align:center;vertical-align:middle;"><?php echo $nm;?></td>
                                                <td style="text-align:center;vertical-align:middle;"><img src="<?php echo base_url('assets/foto/'.$foto);?>" style="max-width:100px;max-height:80px"></td>
                                                <td style="text-align:right;vertical-align:middle"><?php echo 'Rp '.number_format($harga);?></td>
                                                <td style="text-align:center;vertical-align:middle"><?php echo $stok;?></td>
                                                <td style="text-align:center;vertical-align:middle">
                                                <form action="<?php echo base_url().'admin/penjualan/add_to_cart'?>" method="post">
                                                <input type="hidden" name="kode_brg" value="<?php echo $id?>">
                                                <input type="hidden" name="nabar" value="<?php echo $nm;?>">
                                                <input type="hidden" name="satuan" value="<?php echo $satuan;?>">
                                                <input type="hidden" name="stok" value="<?php echo $stok;?>">
                                                <input type="hidden" name="foto" value="<?php echo $foto;?>">
                                                <input type="hidden" name="harjul" value="<?php echo number_format($harga);?>">
                                                <input type="hidden" name="diskon" value="0">
                                                <input type="hidden" name="qty" value="1" required>
                                                    <button type="submit" class="btn btn-xs btn-info" title="Pilih"><span class="fa fa-edit"></span> Pilih</button>
                                                </form>
                                                </td>
                                            </tr>
                                        <?php endforeach;?>
                                    </tbody>
                                </table>          
                            </div>
                            <div class="modal-footer">
                                <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>    
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <!-- Footer -->
                <footer>
                    <div class="row">
                        <div class="col-lg-12">
                            <p style="text-align:center;">Copyright &copy; <?php echo '2019';?> Koki Restaurant</p>
                        </div>
                    </div>
                    <!-- /.row -->
                </footer>
            </div>
        </div>
    </div>
    <!-- jQuery -->
    <script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url().'assets/dist/js/bootstrap-select.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/dataTables.bootstrap.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.price_format.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap-datetimepicker.min.js'?>"></script>
    <script type="text/javascript">
        $(function(){
            $('#jml_uang').on("input",function(){
                var total=$('#total2').val();
                var discount=parseFloat($('#discount').val());
                var jumuang=$('#jml_uang').val();
                if ($('#discount').val() == '')
                {
                    var discount2 = 0;
                }
                else
                {
                    var discount2 = (discount * total) / 100;
                }
                var hsl=jumuang.replace(/[^\d]/g,"");
                $('#jml_uang2').val(hsl);
                $('#kembalian').val(hsl-total);
            });
            $('#discount').on("input",function(){
                var total=$('#total').val() - $('#tax').val() - $('#service').val();
                var discount=parseFloat($('#discount').val());
                var discount2 = (discount * total) / 100;
                if ($('#discount').val() == '')
                {
                    $('#discount2').val(0);
                    $('#total2').val($('#total').val());
                }
                else
                {
                    $('#discount2').val(discount2);
                    $('#total2').val($('#total').val()-discount2);                    
                }
                $('#jml_uang').val(0);
                $('#jml_uang2').val(0);
                $('#kembalian').val(0);
            })
        });
        $('.discount').on('input', function() {
            this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#mydata').DataTable();
        } );
    </script>
    <script type="text/javascript">
        $(function(){
            $('.jml_uang').priceFormat({
                    prefix: '',
                    //centsSeparator: '',
                    centsLimit: 0,
                    thousandsSeparator: ','
            });
            $('#jml_uang2').priceFormat({
                    prefix: '',
                    //centsSeparator: '',
                    centsLimit: 0,
                    thousandsSeparator: ''
            });
            $('#kembalian').priceFormat({
                    prefix: '',
                    //centsSeparator: '',
                    centsLimit: 0,
                    thousandsSeparator: ','
            });
            $('.harjul').priceFormat({
                    prefix: '',
                    //centsSeparator: '',
                    centsLimit: 0,
                    thousandsSeparator: ','
            });
        });
        
    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            //Ajax kabupaten/kota insert
            $("#kode_brg").focus();
            $("#kode_brg").on("input",function(){
                var kobar = {kode_brg:$(this).val()};
                   $.ajax({
               type: "POST",
               url : "<?php echo base_url().'admin/penjualan/get_menu';?>",
               data: kobar,
               success: function(msg){
               $('#detail_barang').html(msg);
               }
            });
            }); 

            $("#kode_brg").keypress(function(e){
                if(e.which==13){
                    $("#jumlah").focus();
                }
            });
        });
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
          $("#menu").click(function(e) {
            e.preventDefault();
          $("#container").toggleClass("toggled");
          });
      });
    </script>
    
</body>

</html>
