<html lang="en" moznomarginboxes mozdisallowselectionprint>
<head>
    <title>Buku Besar</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>"/>
</head>
<body onload="window.print()">
    <?php
    $k  = $keuangan->row();
    ?>
    <div class="container">
        <div style="text-align:center">
            <h3>Buku Besar</h3>
            <p></p>
        </div>
		  <div class="row">
            <div class="col-md-6 col-md-offset-2">
                <h4>Nama Perkiraan : Kas</h4>
            </div>
            <div class="col-md-2" style="text-align:right">
                <h4>No. 100</h4>
            </div>
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align:center" width="120px">Tanggal</th>
                            <th style="text-align:center">Keterangan</th>
                            <th style="text-align:center" width="100px">Debit</th>
                            <th style="text-align:center" width="100px">Kredit</th>
                            <th style="text-align:center" width="100px">Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $bulan; ?></td>
                            <td>Kas Usaha Bulan <?php echo date('F', strtotime($bulan)); ?></td>
                            <td style="text-align:right"><?php echo number_format($k->modal +$pendapatan, 0, ',', '.'); ?></td>
                            <td style="text-align:center">-</td>
                            <td style="text-align:right"><?php echo number_format($k->modal +$pendapatan, 0, ',', '.'); ?></td>
                        </tr>
                    </tbody> 
                </table>
            </div>
        </div>
		       
        <div class="row">
            <div class="col-md-6 col-md-offset-2">
                <h4>Nama Perkiraan : Modal</h4>
            </div>
            <div class="col-md-2" style="text-align:right">
                <h4>No. 311</h4>
            </div>
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align:center" width="120px">Tanggal</th>
                            <th style="text-align:center">Keterangan</th>
                            <th style="text-align:center" width="100px">Debit</th>
                            <th style="text-align:center" width="100px">Kredit</th>
                            <th style="text-align:center" width="100px">Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $bulan; ?></td>
                            <td>Setoran Modal</td>
                            <td style="text-align:center">-</td>
                            <td style="text-align:right"><?php echo number_format($k->modal , 0, ',', '.'); ?></td>
                            <td style="text-align:right"><?php echo number_format($k->modal , 0, ',', '.'); ?></td>
                        </tr>
                    </tbody> 
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-2">
                <h4>Nama Perkiraan : Penjualan</h4>
            </div>
            <div class="col-md-2" style="text-align:right">
                <h4>No. 411</h4>
            </div>
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align:center" width="120px">Tanggal</th>
                            <th style="text-align:center">Keterangan</th>
                            <th style="text-align:center" width="100px">Debit</th>
                            <th style="text-align:center" width="100px">Kredit</th>
                            <th style="text-align:center" width="100px">Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $bulan; ?></td>
                            <td>Penerimaan</td>
                            <td style="text-align:center">-</td>
                            <td style="text-align:right"><?php echo number_format($pendapatan, 0, ',', '.'); ?></td>
                            <td style="text-align:right"><?php echo number_format($pendapatan, 0, ',', '.'); ?></td>
                        </tr>
                    </tbody> 
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-2">
                <h4>Nama Perkiraan : Beban Gaji</h4>
            </div>
            <div class="col-md-2" style="text-align:right">
                <h4>No. 511</h4>
            </div>
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align:center" width="120px">Tanggal</th>
                            <th style="text-align:center">Keterangan</th>
                            <th style="text-align:center" width="100px">Debit</th>
                            <th style="text-align:center" width="100px">Kredit</th>
                            <th style="text-align:center" width="100px">Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $bulan; ?></td>
                            <td>Gaji Bulan <?php echo date('F', strtotime($bulan)); ?></td>
                            <td style="text-align:right"><?php echo number_format($k->gaji, 0, ',', '.'); ?></td>
                            <td style="text-align:center">-</td>
                            <td style="text-align:right"><?php echo number_format($k->gaji, 0, ',', '.'); ?></td>
                        </tr>
                    </tbody> 
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-2">
                <h4>Nama Perkiraan : Pembelian Bahan dan Peralatan</h4>
            </div>
            <div class="col-md-2" style="text-align:right">
                <h4>No. 611</h4>
            </div>
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align:center" width="120px">Tanggal</th>
                            <th style="text-align:center">Keterangan</th>
                            <th style="text-align:center" width="100px">Debit</th>
                            <th style="text-align:center" width="100px">Kredit</th>
                            <th style="text-align:center" width="100px">Saldo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $bulan; ?></td>
                            <td>Pembelian Perlengkapan Usaha</td>
                            <td style="text-align:right"><?php echo number_format($k->pembelian, 0, ',', '.'); ?></td>
                            <td style="text-align:center">-</td>
                            <td style="text-align:right"><?php echo number_format($k->pembelian, 0, ',', '.'); ?></td>
                        </tr>
                    </tbody> 
                </table>
            </div>
        </div>
    </div>
</body>
</html>
