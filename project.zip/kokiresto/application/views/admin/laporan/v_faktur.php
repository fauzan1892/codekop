<html lang="en" moznomarginboxes mozdisallowselectionprint>
<head>
    <title>Faktur Penjualan Koki Restaurant</title> 
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/laporan.css')?>"/>
</head>
<body onload="window.print()">
<div id="laporan">
<table align="center" style="width:700px; border-bottom:3px double;border-top:none;border-right:none;border-left:none;margin-top:5px;margin-bottom:20px;">
<!--<tr>
    <td><img src="<?php echo base_url().'assets/img/kop_surat.png'?>"/></td>
</tr>-->
</table>

<table border="0" align="center" style="width:700px; border:none;margin-top:5px;margin-bottom:0px;">
<tr>
    
</tr>
                       
</table>
<?php 
    $b=$data->row_array();
?>
<table border="0" align="center" style="width:700px;border:none;">
        <tr>
            <th style="text-align:left;">Tanggal</th>
            <th style="text-align:left;">: <?php echo $b['jual_tanggal'];?></th>
            <th style="text-align:left;">P</th>
            <th style="text-align:left;width:80px">: <?php echo $b['jual_pax'];?></th>
            <th style="text-align:left;">T</th>
            <th style="text-align:left;width:80px">: <?php echo $b['jual_table'];?></th>
            <th style="text-align:left;">No Bill</th>
            <th style="text-align:left;">: <?php echo $b['jual_nofak'];?></th>
        </tr>
</table>

<table align="center" style="width:700px;margin-bottom:20px;border:none;">
<thead>

    <tr style="border:1px solid #000;">
        <th style="width:50px;border:1px solid #000;">No</th>
        <th style="border:1px solid #000;">Nama Menu</th>
        <th style="border:1px solid #000;">Qty</th>
        <th style="border:1px solid #000;">Price</th>
        <th style="border:1px solid #000;">SubTotal</th>
    </tr>
</thead>
<tbody>
<?php
$discount = $b['jual_diskon'] * ($b['jual_total'] - $b['jual_tax'] - $b['jual_service']) / 100;
$no=0;
    foreach ($data->result_array() as $i) {
        $no++;
        
        $nabar=$i['d_jual_barang_nama'];
        $satuan=$i['d_jual_barang_satuan'];
        
        $harjul=$i['d_jual_barang_harjul'];
        $qty=$i['d_jual_qty'];
        $total=$i['d_jual_total'];
?>
    <tr>
        <td style="text-align:center;border:1px solid #000;"><?php echo $no;?></td>
        <td style="text-align:left;border:1px solid #000;"><?php echo $nabar;?></td>
        <td style="text-align:center;border:1px solid #000;"><?php echo $qty;?></td>
        <td style="text-align:right;border:1px solid #000;padding-right:10px"><?php echo 'Rp '.number_format($harjul);?></td>
        <td style="text-align:right;border:1px solid #000;padding-right:10px"><?php echo 'Rp '.number_format($total);?></td>
    </tr>
<?php } ?>
</tbody>
<tfoot>

    <tr>
        <td colspan="4" style="text-align:right;padding-right:10px"><b>Total</b></td>
        <td style="text-align:right;border:1px solid #000;padding-right:10px"><b><?php echo 'Rp '.number_format($b['jual_total'] - $b['jual_tax'] - $b['jual_service']);?></b></td>
    </tr>
    <tr>
        <td colspan="4" style="text-align:right;padding-right:10px"><b>5% Service</b></td>
        <td style="text-align:right;border:1px solid #000;padding-right:10px"><b><?php echo 'Rp '.number_format($b['jual_service']);?></b></td>
    </tr>
    <tr>
        <td colspan="4" style="text-align:right;padding-right:10px"><b>10% Tax</b></td>
        <td style="text-align:right;border:1px solid #000;padding-right:10px"><b><?php echo 'Rp '.number_format($b['jual_tax']);?></b></td>
    </tr>
    <tr>
        <td colspan="4" style="text-align:right;padding-right:10px"><b>Discount</b></td>
        <td style="text-align:right;border:1px solid #000;padding-right:10px"><b><?php echo 'Rp '.number_format($discount);?></b></td>
    </tr>
    <tr>
        <td colspan="4" style="text-align:right;padding-right:10px"><b>Grand Total</b></td>
        <td style="text-align:right;border:1px solid #000;padding-right:10px"><b><?php echo 'Rp '.number_format($b['jual_total'] - $discount);?></b></td>
    </tr>
</tfoot>
</table>
<table align="center" style="width:700px; border:none;margin-top:5px;margin-bottom:20px;">
    <tr>
        <td></td>
</table>
<table align="center" style="width:700px; border:none;margin-top:5px;margin-bottom:20px;">
    <tr>
        <td align="right">Denpasar, <?php echo date('d-M-Y')?></td>
    </tr>
    <tr>
        <td align="right"></td>
    </tr>
   
    <tr>
    <td><br/><br/><br/><br/></td>
    </tr>    
    <tr>
        <td align="right">( <?php echo $this->session->userdata('nama');?> )</td>
    </tr>
    <tr>
        <td align="center"></td>
    </tr>
</table>
<table align="center" style="width:700px; border:none;margin-top:5px;margin-bottom:20px;">
    <tr>
        <th><br/><br/></th>
    </tr>
    <tr>
        <th align="left"></th>
    </tr>
</table>
</div>
</body>
</html>