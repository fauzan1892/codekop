<html lang="en" moznomarginboxes mozdisallowselectionprint>
<head>
    <title>Laporan Laba/rugi</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>"/>
</head>
<body onload="window.print()">
    <?php
    $p  = $pendapatan;
    $j  = $pengeluaran->row();

    $beli = ($pengeluaran->num_rows() > 0) ? $j->pembelian : 0;
    $gaji = ($pengeluaran->num_rows() > 0) ? $j->gaji : 0;
    
    $lk = $p-$hpp;
    $tb = $beli + $gaji;
    $lb =$lk - $tb;
    ?>
    <div class="container">
        <div style="text-align:center">
            <h4>Laporan Laba/Rugi</h4>
            <p>Bulan <?= $bulan; ?></p>
        </div>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <table class="table">
                    <tr>
                        <th colspan="2">Pendapatan</th>
                    </tr>
                    <tr>
                        <td style="padding-left: 50px;">Penjualan Bersih</td>
                        <td style="text-align:right"><?= number_format($p,0,',','.'); ?>,-</td>
                    </tr>
                    <tr>
                        <td><b>Total Pendapatan</b></td>
                        <td style="text-align:right"><b><?= number_format($p,0,',','.'); ?>,-</b></td>
                    </tr>
					<tr>
                        <td><b>HPP</b></td>
                        <td style="text-align:right"><?= number_format($hpp,0,',','.'); ?>,</b>-</td>
                    </tr>
                    <tr>
                        <td><b>Laba Kotor</b></td>
                        <td style="text-align:right"><?= number_format($p-$hpp,0,',','.'); ?>,</b>-</td>
                    </tr>
                    <tr>
                        <th colspan="2">Biaya</th>
                    </tr>
                    <tr>
                        <td style="padding-left: 50px;">Pembelian Peralatan dan Bahan</td>
                        <td style="text-align:right"><?= number_format($beli,0,',','.'); ?>,-</td>
                    </tr>
                    <tr>
                        <td style="padding-left: 50px;">Gaji Karyawan</td>
                        <td style="text-align:right"><?= number_format($gaji,0,',','.'); ?>,-</td>
                    </tr>
                    <tr>
                        <td><b>Total Biaya</b></td>
                        <td style="text-align:right"><b><?= number_format(($beli + $gaji),0,',','.'); ?>,-</b></td>
                    </tr>
                    <tr>
                        <td><b>Laba Bersih</b></td>
                        <td style="text-align:right"><b><?= number_format($lb,0,',','.'); ?>,-</b></td>
                    </tr>
                </table> 
            </div>
        </div>
    </div>
</body>
</html>