<html lang="en" moznomarginboxes mozdisallowselectionprint>
<head>
    <title>Laporan Modal Awal</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>"/>
</head>
<body onload="window.print()">
    <?php
    $u  = $keuangan->row();

    $jual = $pendapatan;
    $modal = ($keuangan->num_rows() > 0) ? $u->modal : 0;
    $prive = ($keuangan->num_rows() > 0) ? $u->prive : 0;
    $hsl = $jual;
    $lb = ($hsl - $prive);
    ?>
    <div class="container">
        <div style="text-align:center">
            <h4>Laporan Perubahan Modal</h4>
            <p>Bulan <?= $bulan; ?></p>
        </div>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-bordered">
                    <tr>
                        <td>
                            <p><b>Modal Awal Per 1 <?php echo $bulan; ?></b></p>
                            <p>&nbsp;</p>
                            <p>Penambahan Modal</p>
                            <p style="padding-left:50px">Laba Bersih</p>
                            <p style="padding-left:50px">Prive</p>
                            <p>&nbsp;</p>
                            <p><b>Modal Akhir Per <?php echo date('t F Y', strtotime($bulan)); ?></b></p>
                        </td>
                        <td width="200px" style="text-align:right">
                            <p><b>&nbsp;</b></p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                            <p>
                                <?php if ($hsl < 0) echo '-'; ?> Rp. <?php echo number_format(str_replace('-','', $hsl),0,',','.'); ?>,-
                            </p>
                            <p>(Rp. <?php echo number_format($prive,0,',','.'); ?>,-)</p>
                        </td>
                        <td width="200px" style="text-align:right">
                            <p>Rp. <?php echo number_format($modal,0,',','.'); ?>,-</p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                            <p>
                                <?php if (($hsl - $prive) < 0) echo '-'; ?> Rp. <?php echo number_format(str_replace('-','', $lb),0,',','.'); ?>,-
                            </p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                            <p><p>Rp. <?php echo number_format($modal + $lb,0,',','.'); ?>,-</p></p>
                        </td>
                    </tr> 
                </table>
            </div>
        </div>
    </div>
</body>
</html>
