<html lang="en" moznomarginboxes mozdisallowselectionprint>
<head>
    <title>Neraca Saldo</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>"/>
</head>
<body onload="window.print()">
    <?php
    $p  = $pendapatan->row();
    $k  = $keuangan->row();

    $jual = ($pendapatan->num_rows() > 0) ? $p->harga : 0;

    $kas = $k->modal + $k->hutang - $k->piutang - $k->prive - $k->gaji - $k->pembelian;
    ?>
    <div class="container">
        <div style="text-align:center">
            <h4>Neraca Saldo</h4>
            <p>Bulan <?= $bulan; ?></p>
        </div>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th width="20px">No</th>
                            <th style="text-align:center">Nama Rekening</th>
                            <th style="text-align:center" width="200px">Debit</th>
                            <th style="text-align:center" width="200px">Kredit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>101</td>
                            <td>Kas</td>
                            <td style="text-align:right"><?php echo number_format($kas, 0, ',', '.'); ?></td>
                            <td></td>
                        </tr>
                        
                       
                        <tr>
                            <td>311</td>
                            <td>Modal Usaha</td>
                            <td></td>
                            <td style="text-align:right"><?php echo number_format($k->modal, 0, ',', '.'); ?></td>
                        </tr>
						 <tr>
                            <td>312</td>
                            <td>Prive</td>
                            <td style="text-align:right"><?php echo number_format($k->prive, 0, ',', '.'); ?></td>
                            <td></td>
                        </tr>
						<tr>
                            <td>511</td>
                            <td>Gaji Karyawan</td>
                            <td style="text-align:right"><?php echo number_format($k->gaji, 0, ',', '.'); ?></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>611</td>
                            <td>Pembelian Peralatan dan Bahan</td>
                            <td style="text-align:right"><?php echo number_format($k->pembelian, 0, ',', '.'); ?></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="text-align:center" colspan="2"><b>Total</b></td>
                            <td style="text-align:right"><b>Rp. <?php echo number_format(($k->pembelian + $kas + $k->piutang + $k->prive + $k->gaji), 0, ',', '.'); ?></b></td>
                            <td style="text-align:right"><b>Rp. <?php echo number_format(($k->modal + $k->hutang), 0, ',', '.'); ?></b></td>
                        </tr>
                    </tbody> 
                </table>
            </div>
        </div>
    </div>
</body>
</html>