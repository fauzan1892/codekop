<html lang="en" moznomarginboxes mozdisallowselectionprint>
<head>
    <title>Laporan Penjualan Pertanggal</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/laporan.css')?>"/>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>"/>
</head>
<body onload="window.prints()">
<div id="laporan" class="container col-md-8 col-lg-8 col-sm-8 col-md-offset-2">
        <div style="text-align:center">
            <h4>Neraca</h4>
            <p>Bulan <?= $bulan; ?></p>
            <br />
        </div>
        <div class="row">
		<div class="col-md-6 col-lg-6 col-sm-6">
                <div class="row">
                    <div class="col-md-10"><b>Aktiva</b></div>
                </div>
        </div>
		<div class="col-md-6 col-lg-6 col-sm-6">
				<div class="row">
                    <div class="col-md-10"><b>Pasiva</b></div>
                </div>
		</div>
		</div>
</div>

<?php
$total_hutang_usaha = $report->hutang + $report->gaji;
$total_hutang_usaha_modal = $total_hutang_usaha + $report->modal;

$p  = $pendapatan->row();
$k  = $keuangan->row();
	
$jual = ($pendapatan->num_rows() > 0) ? $p->harga : 0;
$kas = $k->modal + $k->hutang - $k->piutang - $k->prive - $k->gaji - $k->pembelian;
$aktiva_lancar = $kas + $k->pembelian ;
$aktiva_tetap = $k->pembelian + $k->pembelian;
$total_aktiva = $aktiva_lancar + $aktiva_tetap;
?>
<div class="container col-md-8 col-lg-8 col-sm-8 col-md-offset-2">

        <div class="row">
		<div class="col-md-6 col-lg-6 col-sm-6" style="padding:20px;border: 1px solid #000; border-left: none; border-bottom: none;">
                <div class="row">
                    <div class=""><b>Aktiva Lancar</b></div>
                </div>
				
				
				<table class="row">
                    <tr>
                        <td colspan="2" width="120px">Kas</td>
                        <td>:</td>
                        <td style="text-align:right">Rp <?= number_format($kas,0,',','.'); ?>,-</td>
                    </tr>
                    <tr>
                        <td colspan="2" width="120px">Bank</td>
                        <td>:</td>
                        <td style="text-align:right">Rp 0,-</td>
                    </tr>
                    <tr>
                        <td colspan="2" width="120px">Perlengkapan</td>
                        <td>:</td>
                        <td style="text-align:right">Rp <?= number_format($k->pembelian,0,',','.'); ?>,-</td>
                    </tr>
                   
				</table>
				
				<div class="row" style="margin-top:10px">
					<div class="col-md-7">
							<div class="row">
								<div class="col-md-10"><b>Total Aktiva Lancar</b></div>
							</div>
					</div>
					<div class="col-md-5">
							<div class="row">
								<div class="col-md-10" style="text-align:right">: <b>Rp <?= number_format($aktiva_lancar,0,',','.'); ?>,-</b></div>
							</div>
					</div>
				</div>
				
				<!-- aktiva tetap -->
				<div class="row" style="margin-top:10px;margin-top:20px">
                    <div class=""><b>Aktiva Tetap : </b></div>
                </div>
				
				
				<table class="row" style="margin-top:10px;margin-top:20px">
                    <tr>
                        <td colspan="2" width="220px">Peralatan</td>
                        <td>:</td>
                        <td style="text-align:right">Rp <?= number_format($k->pembelian,0,',','.'); ?>,-</td>
                    </tr>
                    <tr>
                        <td colspan="2">Akum peny peralatan</td>
                        <td>:</td>
                        <td style="text-align:right">Rp <?= number_format($k->pembelian,0,',','.'); ?>,-</td>
                    </tr>
				</table>
				
				<div class="row" style="margin-top:10px;margin-top:20px">
					<div class="col-md-7">
							<div class="row">
								<div class="col-md-10"><b>Total Aktiva Tetap</b></div>
							</div>
					</div>
					<div class="col-md-5">
							<div class="row">
								<div class="col-md-10">: <b>Rp <?= number_format($aktiva_tetap,0,',','.'); ?>,-</b></div>
							</div>
					</div>
				</div>
        </div>
		<div class="col-md-6 col-lg-6 col-sm-6" style="padding:20px;border: 1px solid #000; border-right: none; border-bottom: none;">
				
				<div class="row">
                    <div class=""><b>Hutang : </b></div>
                </div>
				
				
				<table class="row">
                    <tr>
                        <td colspan="2" width="120px">Hutang usaha</td>
                        <td>:</td>
                        <td style="text-align:right">Rp <?= number_format($report->hutang,0,',','.'); ?>,-</td>
                    </tr>
                    <tr>
                        <td colspan="2" width="120px">Hutang gaji</td>
                        <td>:</td>
                        <td style="text-align:right">Rp <?= number_format($report->gaji,0,',','.'); ?>,-</td>
                    </tr>
				</table>
				
				<div class="row" style="margin-top:10px;text-align:right">
					<div class="col-md-7">
							<div class="row">
								<div class="col-md-10"><b>Total Hutang Usaha</b></div>
							</div>
					</div>
					<div class="col-md-5">
							<div class="row">
								<div class="col-md-10">: <b>Rp <?= number_format($total_hutang_usaha,0,',','.'); ?>,-</b></div>
							</div>
					</div>
				</div>
				
				<!-- aktiva tetap -->
				<div class="row" style="margin-top:10px;margin-top:20px">
                    <div class=""><b>MODAL</b></div>
                </div>
				
				
				<table class="row" style="margin-top:10px;margin-top:20px">
                    <tr>
                        <td colspan="2" width="220px">Modal</td>
                        <td>:</td>
                        <td>Rp <?= number_format($report->modal,0,',','.'); ?>,-</td>
                    </tr>
				</table>
				
				<div class="row" style="margin-top:10px;margin-top:20px">
					<div class="col-md-7">
							<div class="row">
								<div class="col-md-10"><b>Total Modal</b></div>
							</div>
					</div>
					<div class="col-md-5">
							<div class="row">
								<div class="col-md-10">: <b>Rp <?= number_format($report->modal,0,',','.'); ?>,-</b></div>
							</div>
					</div>
				</div>
				
		</div>
		</div>
		
		<div class="row">
		<div class="col-md-6 col-lg-6 col-sm-6" style="border-right: 1px solid #000;">
				
				<div class="row" style="margin-top:10px">
					<div class="col-md-7">
							<div class="row">
								<div class="col-md-10"><b>TOTAL AKTIVA</b></div>
							</div>
					</div>
					<div class="col-md-5">
							<div class="row">
								<div class="col-md-10">: <b>Rp <?= number_format($total_aktiva,0,',','.'); ?>,-</b></div>
							</div>
					</div>
				</div>
		</div>
		<div class="col-md-6 col-lg-6 col-sm-6" style="border-left: 1px solid #000;">
				<div class="row" style="margin-top:10px">
					<div class="col-md-7">
							<div class="row">
								<div class="col-md-10"><b>TOTAL HUTANG + MODAL</b></div>
							</div>
					</div>
					<div class="col-md-5">
							<div class="row">
								<div class="col-md-10">: <b>Rp <?= number_format($total_hutang_usaha_modal,0,',','.'); ?>,-</b></div>
							</div>
					</div>
				</div>
		</div>
		</div> 
		
		
</div>

</body>
</html>