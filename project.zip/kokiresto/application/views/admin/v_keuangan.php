<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Koki">
    <meta name="author" content="Koki">

    <title>Management data keuangan</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url().'assets/css/bootstrap.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/style.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/font-awesome/css/font-awesome.css'?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url().'assets/css/dataTables.bootstrap.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/jquery.dataTables.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/dist/css/bootstrap-select.css'?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap-datetimepicker.min.css'?>">
    <style type="text/css">
      #container {
        padding-left: 0;
        -webkit-transition: all 0.5s ease;
        -moz-transition: all 0.5s ease;
        -o-transition: all 0.5s ease;
        transition: all 0.5s ease;
      }

    #container.toggled {
        padding-left: 250px;
    }

    #sidebar {
        z-index: 1000;
        position: fixed;
        left: 250px;
        width: 0;
        height: 100%;
        margin-left: -250px;
        overflow-y: auto;
        background: #2c3e50;
        -webkit-transition: all 0.5s ease;
        -moz-transition: all 0.5s ease;
        -o-transition: all 0.5s ease;
        transition: all 0.5s ease;
    }

    #container.toggled #sidebar {
        width: 250px;
    }

    #page-content-container {
        width: 100%;
        position: absolute;
        padding: 15px;
    }

    #container.toggled #page-content-container {
        position: absolute;
        margin-right: -250px;
    }

    .sidebar-nav {
        position: absolute;
        top: 0;
        width: 250px;
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .sidebar-nav li {
        text-indent: 10px;
        line-height: 40px;
    }

    .sidebar-nav li h4{
      color: #fff;
      text-align: center;
      font-size: 25px;
        text-indent: 0px;
        line-height: 40px;
    }

    .sidebar-nav li a {
        display: block;
        text-decoration: none;
        color: #fff;
    }
    .sidebar-nav li a i.fa {
      margin-right: 5px;
    }
    .sidebar-nav li a:hover {
        text-decoration: none;
        color: #fff;
        background: #34495f;
    }

    .sidebar-nav li a:active,
    .sidebar-nav li a:focus {
        text-decoration: none;
    }

    .sidebar-nav li a.active {
      text-decoration: none;
        color: #fff;
      background: #34495f;
      border-right: 5px solid #0277bd;
    }

    .sidebar-nav > .sidebar-brand {
        height: 65px;
        font-size: 18px;
        line-height: 60px;
    }

    .sidebar-nav > .sidebar-brand a:hover {
        color: #fff;
        background: none;
        font-weight: bold;
    }
    .user-info {
      padding-left: 15px;
      color: #fff;
      margin-top: 20px;
    }
    .user-info img {
      float: left;
    }
    .user-info p {
      margin-top: -15px;
      font-weight: bold;
    }
    .avatar {
      border-radius: 50px;
      background: #fff;
      height: 60px;
      width: 60px;
    }
    #menunya {
      display: block;
      width: 100%;
    }
    .devider {
    }
    @media(min-width:768px) {
        #menunya {
          display: none;
        }
        #container {
            padding-left: 250px;
        }

        #container.toggled {
            padding-left: 0;
        }

        #sidebar {
            width: 250px;
        }

        #container.toggled #sidebar {
            width: 0;
        }

        #page-content-container {
            padding: 20px;
            position: relative;
        }

        #container.toggled #page-content-container {
            position: relative;
            margin-right: 0;
        }
    }
    @media(min-width:568px) {
      #menunya {
        display: none;
      }
    }
  </style>
</head>

<body>

<div id="container">
        <?php echo $this->load->view('admin/menu_home'); ?>
        <div id="page-content-container">
            <div class="container-fluid">
                 <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Data
                    <small>Keuangan</small>
                    <div class="pull-right"><a href="#" class="btn btn-sm btn-success" data-toggle="modal" data-target="#largeModal"><span class="fa fa-plus"></span> Tambah Data</a></div>
                </h1>
            </div>
        </div>
        <!-- /.row -->
        <!-- Projects Row -->
        <div class="row">
            <div class="col-lg-12">
            <table class="table table-bordered table-condensed" style="font-size:11px;" id="mydata">
                <thead>
                    <tr>
                        <th style="text-align:center;width:40px;">No</th>
                        <th>Bulan / Tahun</th>
                        <th>Modal Awal</th>
                        <th>Prive</th>
                        <th>Gaji Karyawan</th>
                        <th>Piutang Usaha</th>
                        <th>Hutang Usaha</th>
                        <th>Pembelian Peralatan</th>
                        <th style="width:100px;text-align:center;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no=0;
                    foreach ($data->result_array() as $a):
                        $no++;
                        $id=$a['id_keuangan'];
                        $bln=date('F Y', strtotime($a['tgl_input']));
                        $modal=number_format($a['modal'],0,',','.');
                        $prive=number_format($a['prive'],0,',','.');
                        $gaji=number_format($a['gaji'],0,',','.');
                        $piutang=number_format($a['piutang'],0,',','.');
                        $hutang=number_format($a['hutang'],0,',','.');
                        $peralatan=number_format($a['pembelian'],0,',','.');
                    ?>
                    <tr>
                        <td style="text-align:center;"><?php echo $no;?></td>
                        <td><?php echo $bln;?></td>
                        <td style="text-align:right;"><?php echo 'Rp '.$modal;?></td>
                        <td style="text-align:right;"><?php echo 'Rp '.$prive;?></td>
                        <td style="text-align:right;"><?php echo 'Rp '.$gaji;?></td>
                        <td style="text-align:right;"><?php echo 'Rp '.$piutang;?></td>
                        <td style="text-align:right;"><?php echo 'Rp '.$hutang;?></td>
                        <td style="text-align:right;"><?php echo 'Rp '.$peralatan;?></td>
                        <td style="text-align:center;">
                            <a class="btn btn-xs btn-warning" href="#modalEditKeuangan<?php echo $id?>" data-toggle="modal" title="Edit"><span class="fa fa-edit"></span> Edit</a>
                            <a class="btn btn-xs btn-danger" href="#modalHapusKeuangan<?php echo $id?>" data-toggle="modal" title="Hapus"><span class="fa fa-close"></span> Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach;?>
                </tbody>
            </table>
            </div>
        </div>
        <!-- /.row -->
        
        <!-- ============ MODAL ADD =============== -->
        <div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah Data Keuangan</h3>
            </div>
            <form class="form-horizontal" method="post" action="<?php echo base_url().'admin/keuangan/tambah'?>">
                <div class="modal-body">

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Tanggal</label>
                        <div class="col-xs-9">
                            <div class='input-group date' id='datepicker' style="width:300px;">
                                <input type='text' name="tgl" class="form-control" value="" placeholder="Tanggal..." required/>
                                <span class="input-group-addon">
                                    <span class="fa fa-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>

                     <div class="form-group">
                            <label class="control-label col-xs-3" >Modal Awal</label>
                            <div class="col-xs-9">
                                <input type="text" name="modal" class="angka form-control" value="" placeholder="Modal Awal" required style="width:335px;" />
                            </div>
                        </div>

                 

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Prive</label>
                        <div class="col-xs-9">
                            <input type="text" name="prive" class="angka form-control" value="" placeholder="Prive" required style="width:335px;" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Gaji Karyawan</label>
                        <div class="col-xs-9">
                            <input type="text" name="gaji" class="angka form-control" value="" placeholder="Gaji Karyawan" required style="width:335px;" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Hutang Usaha</label>
                        <div class="col-xs-9">
                            <input type="text" name="hutang" class="angka form-control" value="" placeholder="Hutang Usaha" required style="width:335px;" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Piutang Usaha</label>
                        <div class="col-xs-9">
                            <input type="text" name="piutang" class="angka form-control" value="" placeholder="Piutang Usaha" required style="width:335px;" />
                        </div>
                    </div>                        

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Pembelian Peralatan</label>
                        <div class="col-xs-9">
                            <input type="text" name="pembelian" class="angka form-control" value="" placeholder="Pembelian Peralatan" required style="width:335px;" />
                        </div>
                    </div>                        

                </div>

                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        <hr>

        <!-- modal edit dan hapus -->
        <?php
        foreach ($data->result_array() as $b):
            $id=$b['id_keuangan'];
            $tgl=$b['tgl_input'];
            $modal=$b['modal'];
            $prive=$b['prive'];
            $gaji=$b['gaji'];
            $piutang=$b['piutang'];
            $hutang=$b['hutang'];
            $pembelian=$b['pembelian'];
        ?>
            <!-- modal edit -->
            <div class="modal fade" id="modalEditKeuangan<?php echo $id?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
                <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h3 class="modal-title" id="myModalLabel">Tambah Data Keuangan</h3>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo base_url().'admin/keuangan/edit'?>">
                    <div class="modal-body">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <div class="form-group">
                            <label class="control-label col-xs-3" >Tanggal</label>
                            <div class="col-xs-9">
                                <div class='input-group date datepicker' style="width:300px;">
                                    <input type='text' name="tgl" class="form-control" value="<?php echo $tgl; ?>" placeholder="Tanggal..." required/>
                                    <span class="input-group-addon">
                                        <span class="fa fa-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        </div>

                         <div class="form-group">
                                <label class="control-label col-xs-3" >Modal Awal</label>
                                <div class="col-xs-9">
                                    <input type="text" name="modal" class="angka form-control" value="<?php echo $modal; ?>" placeholder="Modal Awal" required style="width:335px;" />
                                </div>
                            </div>

                     

                        <div class="form-group">
                            <label class="control-label col-xs-3" >Prive</label>
                            <div class="col-xs-9">
                                <input type="text" name="prive" class="angka form-control" value="<?php echo $prive; ?>" placeholder="Prive" required style="width:335px;" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-xs-3" >Gaji Karyawan</label>
                            <div class="col-xs-9">
                                <input type="text" name="gaji" class="angka form-control" value="<?php echo $gaji; ?>" placeholder="Gaji Karyawan" required style="width:335px;" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-xs-3" >Hutang Usaha</label>
                            <div class="col-xs-9">
                                <input type="text" name="hutang" class="angka form-control" value="<?php echo $hutang; ?>" placeholder="Hutang Usaha" required style="width:335px;" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-xs-3" >Piutang Usaha</label>
                            <div class="col-xs-9">
                                <input type="text" name="piutang" class="angka form-control" value="<?php echo $piutang; ?>" placeholder="Piutang Usaha" required style="width:335px;" />
                            </div>
                        </div>                        

                        <div class="form-group">
                            <label class="control-label col-xs-3" >Pembelian Peralatan</label>
                            <div class="col-xs-9">
                                <input type="text" name="pembelian" class="angka form-control" value="<?php echo $pembelian; ?>" placeholder="Piutang Usaha" required style="width:335px;" />
                            </div>
                        </div>    

                    </div>

                    <div class="modal-footer">
                        <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        <button class="btn btn-info">Simpan</button>
                    </div>
                </form>
                </div>
                </div>
            </div>
            <!-- end modal edit -->

            <!-- modal hapus -->
            <div id="modalHapusKeuangan<?php echo $id?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <h3 class="modal-title" id="myModalLabel">Hapus Data Keuangan</h3>
                        </div>
                        <form class="form-horizontal" method="post" action="<?php echo base_url().'admin/keuangan/hapus'?>">
                            <div class="modal-body">
                                <p>Yakin mau menghapus data Keuangan ini..?</p>
                                        <input name="kode" type="hidden" value="<?php echo $id; ?>">
                            </div>
                            <div class="modal-footer">
                                <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                                <button type="submit" class="btn btn-primary">Hapus</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- end modal hapus -->
        <!-- end modal -->
        <?php endforeach; ?>
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center;">Copyright &copy; <?php echo '2019';?> Koki Restaurant</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url().'assets/dist/js/bootstrap-select.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/dataTables.bootstrap.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.price_format.min.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap-datetimepicker.min.js'?>"></script>
    <script type="text/javascript">
        $(function () {
            $('#datepicker').datetimepicker({
                format: 'YYYY-MM-DD',
            });
            $('.datepicker').datetimepicker({
                format: 'YYYY-MM-DD',
            });
        });
    </script>
    <script type="text/javascript">
        $(function(){
            $('.angka').priceFormat({
                    prefix: '',
                    //centsSeparator: '',
                    centsLimit: 0,
                    thousandsSeparator: ','
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#mydata').DataTable();
        } );
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
          $("#menu").click(function(e) {
            e.preventDefault();
          $("#container").toggleClass("toggled");
          });
      });
    </script>
</body>

</html> 
