<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Koki">
    <meta name="author" content="Koki">

    <title>Welcome To Sistem Restaurant</title>

    <!-- Bootstrap Core CSS -->
      <link href="<?php echo base_url().'assets/css/bootstrap.min.css'?>" rel="stylesheet">
	<link href="<?php echo base_url().'assets/css/style.css'?>" rel="stylesheet">
	  <link href="<?php echo base_url().'assets/font-awesome/css/font-awesome.css'?>" rel="stylesheet">
    <!-- Custom CSS -->
      <!-- <link href="<?php echo base_url().'assets/css/4-col-portfolio.css'?>" rel="stylesheet"> -->

      <style type="text/css">
      .bg {
           width: 100%;
           height: 100%;
           position: fixed;
           z-index: -1;
           float: left;
           left: 0;
      }
      #container {
        padding-left: 0;
        -webkit-transition: all 0.5s ease;
        -moz-transition: all 0.5s ease;
        -o-transition: all 0.5s ease;
        transition: all 0.5s ease;
      }

    #container.toggled {
        padding-left: 250px;
    }

    #sidebar {
        z-index: 1000;
        position: fixed;
        left: 250px;
        width: 0;
        height: 100%;
        margin-left: -250px;
        overflow-y: auto;
        background: #2c3e50;
        -webkit-transition: all 0.5s ease;
        -moz-transition: all 0.5s ease;
        -o-transition: all 0.5s ease;
        transition: all 0.5s ease;
    }

    #container.toggled #sidebar {
        width: 250px;
    }

    #page-content-container {
        width: 100%;
        position: absolute;
        padding: 15px;
    }

    #container.toggled #page-content-container {
        position: absolute;
        margin-right: -250px;
    }

    .sidebar-nav {
        position: absolute;
        top: 0;
        width: 250px;
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .sidebar-nav li {
        text-indent: 10px;
        line-height: 40px;
    }

    .sidebar-nav li h4{
      color: #fff;
      text-align: center;
      font-size: 25px;
        text-indent: 0px;
        line-height: 40px;
    }

    .sidebar-nav li a {
        display: block;
        text-decoration: none;
        color: #fff;
    }
    .sidebar-nav li a i.fa {
      margin-right: 5px;
    }
    .sidebar-nav li a:hover {
        text-decoration: none;
        color: #fff;
        background: #34495f;
    }

    .sidebar-nav li a:active,
    .sidebar-nav li a:focus {
        text-decoration: none;
    }

    .sidebar-nav li a.active {
      text-decoration: none;
        color: #fff;
      background: #34495f;
      border-right: 5px solid #0277bd;
    }

    .sidebar-nav > .sidebar-brand {
        height: 65px;
        font-size: 18px;
        line-height: 60px;
    }

    .sidebar-nav > .sidebar-brand a:hover {
        color: #fff;
        background: none;
        font-weight: bold;
    }
    .user-info {
      padding-left: 15px;
      color: #fff;
      margin-top: 20px;
    }
    .user-info img {
      float: left;
    }
    .user-info p {
      margin-top: -15px;
      font-weight: bold;
    }
    .avatar {
      border-radius: 50px;
      background: #fff;
      height: 60px;
      width: 60px;
    }
    #menunya {
      display: block;
      width: 100%;
    }
    .devider {
    }
    @media(min-width:768px) {
        #menunya {
          display: none;
        }
        #container {
            padding-left: 250px;
        }

        #container.toggled {
            padding-left: 0;
        }

        #sidebar {
            width: 250px;
        }

        #container.toggled #sidebar {
            width: 0;
        }

        #page-content-container {
            padding: 20px;
            position: relative;
        }

        #container.toggled #page-content-container {
            position: relative;
            margin-right: 0;
        }
    }
    @media(min-width:568px) {
      #menunya {
        display: none;
      }
    }
  </style>
</head>

<body>
<img src="<?php echo base_url().'assets/img/bg2.jpg'?>" alt="gambar" class="bg" />
<div id="container">
<?php echo $this->load->view('admin/menu_home'); ?>
    <div id="page-content-container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Page Heading -->
                  <div class="row" style="margin-top:-25px">
                      <div class="col-lg-12">
                          <h1 class="page-header"  style =" background-color: #93B874"><marquee>Welcome to Sistem Koki Restaurant</marquee>
                              <small></small>
                          </h1>
                      </div>
                  </div>

                  <div class="mainbody-section text-center">
                  <?php $h=$this->session->userdata('akses'); ?>
                  <?php $u=$this->session->userdata('user'); ?>

                  <!-- Projects Row -->
                  <div class="row" style="margin-top:-50px;">
                    <?php if($h=='1'){ ?> 
                      <div class="col-md-3 col-md-offset-1">
                          <div class="menu-item blue" style="height:150px;">
                               <a href="<?php echo base_url().'admin/penjualan'?>" data-toggle="modal">
                                     <i class="glyphicon glyphicon-menu-hamburger"></i>
                                      <p style="text-align:left;font-size:14px;padding-left:5px;">Penjualan</p>
                                </a>
                          </div> 
                      </div>
           
           
                      <div class="col-md-3 col-md-offset-3">
                          <div class="menu-item color" style="height:150px;">
                               <a href="<?php echo base_url().'admin/kategori'?>" data-toggle="modal">
                                     <i class="fa fa-sitemap"></i>
                                      <p style="text-align:left;font-size:14px;padding-left:5px;">Kategori</p>
                                </a>
                          </div> 
                      </div>
                    <?php }?>
                    <?php if($h=='2'){ ?> 
                      <div class="col-md-3 col-md-offset-4">
                          <div class="menu-item red" style="height:150px;">
                               <a href="<?php echo base_url().'admin/penjualan'?>" data-toggle="modal">
                                     <i class="fa fa-cubes"></i>
                                      <p style="text-align:center;font-size:25px;padding-left:5px;">Penjualan</p>
                                </a>
                          </div> 
                      </div>                   
                    <?php }?>
                  </div> <!-- /.row -->

                  <!-- Projects Row -->
                    <?php if($h=='1'){ ?>
                    <div class="row">
                      <div class="col-md-3 col-md-offset-4">
                          <div class="menu-item purple" style="height:150px;">
                               <a href="<?php echo base_url().'admin/menu'?>" data-toggle="modal">
                                     <i class="fa fa-cutlery"></i>
                                      <p style="text-align:left;font-size:14px;padding-left:5px;">Menu</p>
                                </a>
                          </div> 
                      </div>
                    </div>
                    <div class="row" style="margin-bottom:-100px">
                      <div class="col-md-3 col-md-offset-1">
                          <div class="menu-item red" style="height:150px;">
                               <a href="<?php echo base_url().'admin/pengguna'?>" data-toggle="modal">
                                     <i class="fa fa-users"></i>
                                      <p style="text-align:left;font-size:14px;padding-left:5px;">Pengguna</p>
                                </a>
                          </div> 
                      </div>
                      <div class="col-md-3 col-md-offset-3">
                          <div class="menu-item blue" style="height:150px;">
                               <a href="<?php echo base_url().'admin/laporan'?>" data-toggle="modal">
                                     <i class="fa fa-bar-chart"></i>
                                      <p style="text-align:left;font-size:14px;padding-left:5px;">Laporan</p>
                                </a>
                          </div> 
                      </div>

                    </div>
                  <?php }?>
            </div>
        </div>
    </div>
  </div>
  </div>
  </div>
    <!-- jQuery -->
    <script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>
    <script type="text/javascript">
      $(document).ready(function(){
          $("#menu").click(function(e) {
            e.preventDefault();
          $("#container").toggleClass("toggled");
          });
      });
    </script>
</body>

</html>  
