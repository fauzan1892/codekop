<div id="sidebar">
    <ul class="sidebar-nav">
        <li><h4><a href="<?php echo base_url().'welcome'?>">Koki Restaurant</a></h4></li>
            <?php $h=$this->session->userdata('akses'); ?>
            <?php $u=$this->session->userdata('user'); ?>
            <?php if($h=='1'){ ?>
                    <li>
                        <a href="<?php echo base_url().'admin/penjualan'?>"><span class="fa fa-shopping-cart" aria-hidden="true"></span> Transaksi</a>
                    </li>
                    
                    
                    <li>
                        <a href="<?php echo base_url().'admin/laporan'?>"><span class="fa fa-file"></span> Laporan</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url().'admin/keuangan'?>"><span class="fa fa-money"></span> Keuangan</a>
                    </li>
                    <?php }?>
                    <?php if($h=='2'){ ?> 
                      <!--dropdown-->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="Transaksi"><span class="fa fa-shopping-cart" aria-hidden="true"></span> Transaksi</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url().'admin/penjualan'?>"><span class="fa fa-shopping-bag" aria-hidden="true"></span> Penjualan</a></li> 
                            <li><a href="<?php echo base_url().'admin/penjualan_grosir'?>"><span class="fa fa-cubes" aria-hidden="true"></span> Penjualan (Grosir)</a></li> 
                        </ul>
                    </li>
                    <!--ending dropdown-->
                    
                    <?php }?>
                     <li>
                        <a href="<?php echo base_url().'administrator/logout'?>"><span class="fa fa-sign-out"></span> Logout</a>
                    </li>
    </ul>
</div>
<nav class="navbar navbar-default" id="menunya" style="border-radius:0px;">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header" style="padding-left:10px;">
          <a href="#menu" class="btn btn-default navbar-btn" id="menu"><i class="fa fa-bars"></i></a>
        </div>

        
    </div><!-- /.container-fluid -->
</nav>