-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2019 at 09:17 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kokires2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_detail_jual`
--

CREATE TABLE IF NOT EXISTS `tbl_detail_jual` (
`d_jual_id` int(11) NOT NULL,
  `d_jual_nofak` varchar(15) DEFAULT NULL,
  `d_jual_barang_id` varchar(15) DEFAULT NULL,
  `d_jual_barang_nama` varchar(150) DEFAULT NULL,
  `d_jual_barang_satuan` varchar(30) DEFAULT NULL,
  `d_jual_barang_harjul` double DEFAULT NULL,
  `d_jual_qty` int(11) DEFAULT NULL,
  `d_jual_total` double DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_detail_jual`
--

INSERT INTO `tbl_detail_jual` (`d_jual_id`, `d_jual_nofak`, `d_jual_barang_id`, `d_jual_barang_nama`, `d_jual_barang_satuan`, `d_jual_barang_harjul`, `d_jual_qty`, `d_jual_total`) VALUES
(55, '040519000002', 'BR000003', 'Ayam Bakar', 'Porsi', 30000, 2, 60000),
(56, '040519000002', 'BR000006', 'Es Milo Susu Coklat', 'Gelas', 25000, 3, 75000),
(59, '040519000004', 'BR000002', 'Roti Keju', 'Kotak', 40000, 2, 80000),
(60, '040519000004', 'BR000003', 'Ayam Bakar', 'Porsi', 30000, 2, 60000),
(62, '040519000004', 'BR000005', 'Es Campur', 'Gelas', 25000, 2, 50000),
(63, '050519000001', 'BR000006', 'Es Milo Susu Coklat', 'Gelas', 25000, 1, 25000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jual`
--

CREATE TABLE IF NOT EXISTS `tbl_jual` (
  `jual_nofak` varchar(15) NOT NULL,
  `jual_tanggal` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `jual_tax` double NOT NULL,
  `jual_service` double NOT NULL,
  `jual_diskon` float NOT NULL,
  `jual_total` double DEFAULT NULL,
  `jual_jml_uang` double DEFAULT NULL,
  `jual_kembalian` double DEFAULT NULL,
  `jual_user_id` int(11) DEFAULT NULL,
  `jual_pax` int(11) NOT NULL,
  `jual_table` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_jual`
--

INSERT INTO `tbl_jual` (`jual_nofak`, `jual_tanggal`, `jual_tax`, `jual_service`, `jual_diskon`, `jual_total`, `jual_jml_uang`, `jual_kembalian`, `jual_user_id`, `jual_pax`, `jual_table`) VALUES
('040519000001', '2019-05-04 15:40:21', 20000, 10000, 10, 230000, 250000, 20000, 4, 2, 5),
('040519000002', '2019-05-04 15:42:21', 13500, 6750, 0, 155250, 200000, 44750, 4, 2, 12),
('040519000003', '2019-05-04 15:45:30', 50000, 25000, 0, 575000, 600000, 25000, 4, 10, 15),
('040519000004', '2019-05-04 15:46:38', 34000, 17000, 25, 391000, 400000, 9000, 4, 10, 15),
('050519000001', '2019-05-05 15:48:40', 2500, 1250, 0, 28750, 30000, 1250, 4, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE IF NOT EXISTS `tbl_kategori` (
`kategori_id` int(11) NOT NULL,
  `kategori_nama` varchar(35) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`kategori_id`, `kategori_nama`) VALUES
(40, 'Camilan'),
(41, 'Minuman'),
(42, 'Makanan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_keuangan`
--

CREATE TABLE IF NOT EXISTS `tbl_keuangan` (
`id_keuangan` int(11) NOT NULL,
  `tgl_input` date NOT NULL,
  `modal` double NOT NULL,
  `prive` double NOT NULL,
  `gaji` double NOT NULL,
  `hutang` double NOT NULL,
  `piutang` double NOT NULL,
  `pembelian` double NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_keuangan`
--

INSERT INTO `tbl_keuangan` (`id_keuangan`, `tgl_input`, `modal`, `prive`, `gaji`, `hutang`, `piutang`, `pembelian`) VALUES
(5, '2019-05-04', 10000000, 100000, 200000, 100000, 200000, 200000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE IF NOT EXISTS `tbl_menu` (
  `menu_id` varchar(15) NOT NULL,
  `menu_nama` varchar(150) DEFAULT NULL,
  `menu_satuan` varchar(30) DEFAULT NULL,
  `menu_harga` double DEFAULT NULL,
  `menu_stok` int(11) DEFAULT '0',
  `menu_foto` varchar(50) NOT NULL,
  `menu_min_stok` int(11) DEFAULT '0',
  `menu_tgl_input` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `menu_tgl_last_update` datetime DEFAULT NULL,
  `menu_kategori_id` int(11) DEFAULT NULL,
  `menu_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`menu_id`, `menu_nama`, `menu_satuan`, `menu_harga`, `menu_stok`, `menu_foto`, `menu_min_stok`, `menu_tgl_input`, `menu_tgl_last_update`, `menu_kategori_id`, `menu_user_id`) VALUES
('BR000002', 'Roti Keju', 'Kotak', 40000, 18, 'foto1556983779.jpeg', 5, '2018-11-30 06:20:05', '2019-05-04 23:30:18', 40, 4),
('BR000003', 'Ayam Bakar', 'Porsi', 30000, 15, 'foto1556984091.jpg', 5, '2018-11-30 06:20:28', '2019-05-04 23:34:51', 42, 4),
('BR000005', 'Es Campur', 'Gelas', 25000, 17, 'foto1556983810.jpg', 0, '2018-12-05 06:25:23', '2019-05-04 23:30:10', 41, 4),
('BR000006', 'Es Milo Susu Coklat', 'Gelas', 25000, 12, 'foto1556983852.jpg', 5, '2019-02-16 19:44:09', '2019-05-04 23:30:52', 41, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
`user_id` int(11) NOT NULL,
  `user_nama` varchar(35) DEFAULT NULL,
  `user_username` varchar(30) DEFAULT NULL,
  `user_password` varchar(35) DEFAULT NULL,
  `user_level` varchar(2) DEFAULT NULL,
  `user_status` varchar(2) DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_nama`, `user_username`, `user_password`, `user_level`, `user_status`) VALUES
(3, 'Kasir', 'Kasir', 'c7911af3adbd12a035b289556d96470a', '2', '1'),
(4, 'Admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', '1'),
(5, 'Acounting', 'acounting', '9570578bfcf5219f3f871d4b7698b734', '1', '1'),
(6, 'Maneger', 'maneger', '13c8e4946bb5b71db735c7eb296e80f4', '1', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
 ADD PRIMARY KEY (`d_jual_id`), ADD KEY `d_jual_barang_id` (`d_jual_barang_id`);

--
-- Indexes for table `tbl_jual`
--
ALTER TABLE `tbl_jual`
 ADD PRIMARY KEY (`jual_nofak`), ADD KEY `jual_user_id` (`jual_user_id`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
 ADD PRIMARY KEY (`kategori_id`);

--
-- Indexes for table `tbl_keuangan`
--
ALTER TABLE `tbl_keuangan`
 ADD PRIMARY KEY (`id_keuangan`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
 ADD PRIMARY KEY (`menu_id`), ADD KEY `barang_user_id` (`menu_user_id`), ADD KEY `barang_kategori_id` (`menu_kategori_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
MODIFY `d_jual_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `tbl_keuangan`
--
ALTER TABLE `tbl_keuangan`
MODIFY `id_keuangan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
ADD CONSTRAINT `tbl_detail_jual_ibfk_1` FOREIGN KEY (`d_jual_barang_id`) REFERENCES `tbl_menu` (`menu_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
ADD CONSTRAINT `tbl_menu_ibfk_1` FOREIGN KEY (`menu_user_id`) REFERENCES `tbl_user` (`user_id`) ON UPDATE CASCADE,
ADD CONSTRAINT `tbl_menu_ibfk_2` FOREIGN KEY (`menu_kategori_id`) REFERENCES `tbl_kategori` (`kategori_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
